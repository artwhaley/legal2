"""Small encrypted, content-free SQLite control plane."""

from __future__ import annotations

import hashlib
import json
import os
import secrets
import sqlite3
import subprocess
import time
import uuid
import getpass
from dataclasses import replace
from pathlib import Path
from typing import Any

from cryptography.fernet import Fernet, InvalidToken

from server.config import CHAT_OPERATIONS, EmbeddingConfig, GlobalConfig, OperationConfig, ServerConfig, default_state_dir


TABLES = {
    "control_schema_version", "config_version", "operation_config", "embedding_config",
    "global_config", "encrypted_secret", "config_secret_binding", "admin_audit",
    "usage_event", "legacy_import_receipt",
}


class ConfigurationCorruption(RuntimeError):
    pass


class SecretManager:
    def __init__(self, state_dir: Path):
        self.state_dir = state_dir
        self.key_path = state_dir / "secrets" / "master.key"
        self.key = self._resolve()
        self._fernet = Fernet(self.key)

    def _resolve(self) -> bytes:
        supplied = os.environ.get("EVW_SERVER_MASTER_KEY", "").strip()
        if supplied:
            try:
                Fernet(supplied.encode("ascii"))
            except Exception as exc:
                raise ValueError("EVW_SERVER_MASTER_KEY is not a valid Fernet key") from exc
            return supplied.encode("ascii")
        self.key_path.parent.mkdir(parents=True, exist_ok=True)
        if self.key_path.exists():
            value = self.key_path.read_bytes().strip()
            try:
                Fernet(value)
            except Exception as exc:
                raise ConfigurationCorruption("master key file is invalid") from exc
            self._secure_key_file()
            return value
        value = Fernet.generate_key()
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
        fd = os.open(self.key_path, flags, 0o600)
        try:
            os.write(fd, value)
        finally:
            os.close(fd)
        self._secure_key_file()
        return value

    def _secure_key_file(self) -> None:
        try:
            os.chmod(self.key_path, 0o600)
            if os.name == "nt":
                user = getpass.getuser()
                completed = subprocess.run(
                    [
                        "icacls",
                        str(self.key_path),
                        "/inheritance:r",
                        "/grant:r",
                        f"{user}:(F)",
                        "SYSTEM:(F)",
                    ],
                    capture_output=True,
                    text=True,
                    check=False,
                )
                if completed.returncode != 0:
                    raise OSError("icacls rejected the master-key ACL")
        except OSError as exc:
            raise ConfigurationCorruption("unable to secure master key file") from exc

    def encrypt(self, secret: str) -> bytes:
        return self._fernet.encrypt(secret.encode("utf-8"))

    def decrypt(self, ciphertext: bytes) -> str:
        try:
            return self._fernet.decrypt(ciphertext).decode("utf-8")
        except (InvalidToken, UnicodeDecodeError) as exc:
            raise ConfigurationCorruption("provider secret cannot be decrypted") from exc


class ConfigStore:
    def __init__(self, state_dir: Path | None = None, *, db_path: Path | None = None):
        self.state_dir = (state_dir or default_state_dir()).expanduser().resolve()
        self.state_dir.mkdir(parents=True, exist_ok=True)
        self.db_path = (db_path or self.state_dir / "control.sqlite3").expanduser().resolve()
        self.secrets = SecretManager(self.state_dir)
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self._configure()
        self._migrate()
        self._check_integrity()

    def _configure(self) -> None:
        self.conn.execute("PRAGMA foreign_keys=ON")
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA synchronous=FULL")
        self.conn.commit()

    def _migrate(self) -> None:
        self.conn.executescript("""
        CREATE TABLE IF NOT EXISTS control_schema_version (version INTEGER NOT NULL);
        INSERT INTO control_schema_version(version) SELECT 1 WHERE NOT EXISTS (SELECT 1 FROM control_schema_version);
        CREATE TABLE IF NOT EXISTS config_version (
          version_id INTEGER PRIMARY KEY AUTOINCREMENT,
          config_hash TEXT NOT NULL,
          payload_json TEXT NOT NULL,
          status TEXT NOT NULL CHECK(status IN ('draft','active','superseded')),
          created_at REAL NOT NULL,
          activated_at REAL,
          source TEXT NOT NULL DEFAULT 'admin'
        );
        CREATE UNIQUE INDEX IF NOT EXISTS one_active_config ON config_version(status) WHERE status='active';
        CREATE TABLE IF NOT EXISTS operation_config (
          version_id INTEGER NOT NULL REFERENCES config_version(version_id) ON DELETE CASCADE,
          operation TEXT NOT NULL,
          config_json TEXT NOT NULL,
          PRIMARY KEY(version_id, operation)
        );
        CREATE TABLE IF NOT EXISTS embedding_config (
          version_id INTEGER PRIMARY KEY REFERENCES config_version(version_id) ON DELETE CASCADE,
          config_json TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS global_config (
          version_id INTEGER PRIMARY KEY REFERENCES config_version(version_id) ON DELETE CASCADE,
          config_json TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS encrypted_secret (
          secret_id TEXT PRIMARY KEY,
          ciphertext BLOB NOT NULL,
          key_version INTEGER NOT NULL,
          provider_label TEXT NOT NULL,
          suffix TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS config_secret_binding (
          version_id INTEGER NOT NULL REFERENCES config_version(version_id) ON DELETE CASCADE,
          operation TEXT NOT NULL,
          secret_id TEXT NOT NULL REFERENCES encrypted_secret(secret_id),
          PRIMARY KEY(version_id, operation)
        );
        CREATE TABLE IF NOT EXISTS admin_audit (
          audit_id TEXT PRIMARY KEY,
          action TEXT NOT NULL,
          version_id INTEGER,
          created_at REAL NOT NULL,
          details_json TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS usage_event (
          event_id TEXT PRIMARY KEY,
          request_id TEXT,
          created_at REAL NOT NULL,
          config_version INTEGER NOT NULL,
          product_endpoint TEXT NOT NULL,
          internal_operation TEXT,
          attempt INTEGER,
          provider_or_profile TEXT NOT NULL,
          outcome TEXT NOT NULL,
          error_code TEXT,
          input_tokens INTEGER NOT NULL DEFAULT 0,
          output_tokens INTEGER NOT NULL DEFAULT 0,
          usage_source TEXT NOT NULL,
          input_price_per_million REAL,
          output_price_per_million REAL,
          estimated_cost REAL,
          currency TEXT,
          latency_ms REAL,
          provider_request_id TEXT,
          embedding_item_count INTEGER NOT NULL DEFAULT 0
        );
        CREATE TRIGGER IF NOT EXISTS usage_event_no_update
          BEFORE UPDATE ON usage_event
          BEGIN SELECT RAISE(ABORT, 'usage_event is append-only'); END;
        CREATE TRIGGER IF NOT EXISTS usage_event_no_delete
          BEFORE DELETE ON usage_event
          BEGIN SELECT RAISE(ABORT, 'usage_event is append-only'); END;
        CREATE TABLE IF NOT EXISTS legacy_import_receipt (
          source_hash TEXT PRIMARY KEY,
          imported_at REAL NOT NULL,
          result TEXT NOT NULL,
          details_json TEXT NOT NULL
        );
        """)
        self.conn.commit()

    def _check_integrity(self) -> None:
        versions = self.conn.execute("SELECT version FROM control_schema_version").fetchall()
        if len(versions) != 1 or int(versions[0][0]) != 1:
            raise ConfigurationCorruption("unsupported or ambiguous control database schema version")
        quick = self.conn.execute("PRAGMA quick_check").fetchone()[0]
        foreign = self.conn.execute("PRAGMA foreign_key_check").fetchall()
        if quick != "ok" or foreign:
            raise ConfigurationCorruption("control database integrity check failed")

    @staticmethod
    def _hash(config: ServerConfig) -> str:
        encoded = json.dumps(config.to_dict(), sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        return hashlib.sha256(encoded).hexdigest()

    def _write_config(self, config: ServerConfig, *, status: str, source: str = "admin", version_id: int | None = None) -> int:
        payload = config.to_dict()
        now = time.time()
        data = json.dumps(payload, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
        if version_id is None:
            cursor = self.conn.execute("INSERT INTO config_version(config_hash,payload_json,status,created_at,source) VALUES(?,?,?,?,?)", (self._hash(config), data, status, now, source))
            version_id = int(cursor.lastrowid)
        else:
            self.conn.execute("UPDATE config_version SET config_hash=?,payload_json=? WHERE version_id=? AND status='draft'", (self._hash(config), data, version_id))
            self.conn.execute("DELETE FROM operation_config WHERE version_id=?", (version_id,))
            self.conn.execute("DELETE FROM embedding_config WHERE version_id=?", (version_id,))
            self.conn.execute("DELETE FROM global_config WHERE version_id=?", (version_id,))
        for operation, value in config.operations.items():
            self.conn.execute("INSERT INTO operation_config(version_id,operation,config_json) VALUES(?,?,?)", (version_id, operation, json.dumps(value.to_dict(), sort_keys=True, ensure_ascii=False)))
        self.conn.execute("INSERT INTO embedding_config(version_id,config_json) VALUES(?,?)", (version_id, json.dumps(config.embedding.to_dict(), sort_keys=True)))
        self.conn.execute("INSERT INTO global_config(version_id,config_json) VALUES(?,?)", (version_id, json.dumps(config.global_config.to_dict(), sort_keys=True)))
        return version_id

    def create_draft(self, config: ServerConfig, *, source: str = "admin") -> int:
        config.validate(require_complete=False)
        with self.conn:
            return self._write_config(config, status="draft", source=source)

    def save_draft(self, version_id: int, config: ServerConfig) -> None:
        config.validate(require_complete=False)
        with self.conn:
            row = self.conn.execute("SELECT status FROM config_version WHERE version_id=?", (version_id,)).fetchone()
            if row is None or row[0] != "draft":
                raise ValueError("only a draft version can be saved")
            self._write_config(config, status="draft", version_id=version_id)

    def _row_config(self, row: sqlite3.Row) -> ServerConfig:
        raw = json.loads(row["payload_json"])
        config = ServerConfig.from_dict(raw, config_version=int(row["version_id"]))
        for operation in CHAT_OPERATIONS:
            binding = self.conn.execute("SELECT s.ciphertext FROM config_secret_binding b JOIN encrypted_secret s ON s.secret_id=b.secret_id WHERE b.version_id=? AND b.operation=?", (row["version_id"], operation)).fetchone()
            if binding is not None:
                config = replace(config, operations={**config.operations, operation: replace(config.operations[operation], api_key=self.secrets.decrypt(bytes(binding[0])))})
        return config

    def get_version(self, version_id: int) -> ServerConfig:
        row = self.conn.execute("SELECT * FROM config_version WHERE version_id=?", (version_id,)).fetchone()
        if row is None:
            raise KeyError(version_id)
        try:
            return self._row_config(row)
        except ConfigurationCorruption:
            raise
        except Exception as exc:
            raise ConfigurationCorruption("stored configuration payload is invalid") from exc

    def active(self) -> ServerConfig | None:
        row = self.conn.execute("SELECT * FROM config_version WHERE status='active'").fetchone()
        if row is None:
            return None
        return self.get_version(int(row["version_id"]))

    def draft(self) -> tuple[int, ServerConfig] | None:
        row = self.conn.execute("SELECT * FROM config_version WHERE status='draft' ORDER BY version_id DESC LIMIT 1").fetchone()
        return None if row is None else (int(row["version_id"]), self._row_config(row))

    def _bind_secret(self, version_id: int, operation: str, value: str) -> None:
        if not value:
            return
        secret_id = str(uuid.uuid4())
        self.conn.execute("INSERT INTO encrypted_secret(secret_id,ciphertext,key_version,provider_label,suffix) VALUES(?,?,?,?,?)", (secret_id, self.secrets.encrypt(value), 1, "openai_compatible", value[-4:]))
        self.conn.execute("INSERT OR REPLACE INTO config_secret_binding(version_id,operation,secret_id) VALUES(?,?,?)", (version_id, operation, secret_id))

    def set_secret(self, version_id: int, operation: str, value: str, *, remove: bool = False) -> None:
        if operation not in CHAT_OPERATIONS:
            raise ValueError("unknown operation")
        with self.conn:
            row = self.conn.execute("SELECT status FROM config_version WHERE version_id=?", (version_id,)).fetchone()
            if row is None or row[0] != "draft":
                raise ValueError("secrets can only be changed on drafts")
            if remove:
                self.conn.execute("DELETE FROM config_secret_binding WHERE version_id=? AND operation=?", (version_id, operation))
            elif value:
                self._bind_secret(version_id, operation, value)

    def secret_projection(self, version_id: int) -> dict[str, dict[str, Any]]:
        rows = self.conn.execute("SELECT b.operation,s.provider_label,s.suffix FROM config_secret_binding b JOIN encrypted_secret s ON s.secret_id=b.secret_id WHERE b.version_id=?", (version_id,)).fetchall()
        return {str(row[0]): {"provider": str(row[1]), "configured": True, "suffix": str(row[2])} for row in rows}

    def encrypted_secret_bindings(self, version_id: int) -> dict[str, bytes]:
        rows = self.conn.execute(
            "SELECT b.operation,s.ciphertext FROM config_secret_binding b JOIN encrypted_secret s ON s.secret_id=b.secret_id WHERE b.version_id=?",
            (version_id,),
        ).fetchall()
        bindings = {str(row[0]): bytes(row[1]) for row in rows}
        missing = [operation for operation in CHAT_OPERATIONS if operation not in bindings]
        if missing:
            raise ConfigurationCorruption(f"active configuration has missing secret bindings: {missing}")
        return bindings

    def validate_version(self, version_id: int) -> None:
        config = self.get_version(version_id)
        config.validate(require_complete=True)

    def activate(self, version_id: int) -> ServerConfig:
        with self.conn:
            row = self.conn.execute("SELECT status FROM config_version WHERE version_id=?", (version_id,)).fetchone()
            if row is None or row[0] != "draft":
                raise ValueError("only a draft version can be activated")
            config = self.get_version(version_id)
            config.validate(require_complete=True)
            self.conn.execute("UPDATE config_version SET status='superseded' WHERE status='active'")
            self.conn.execute("UPDATE config_version SET status='active',activated_at=? WHERE version_id=?", (time.time(), version_id))
            self.conn.execute("INSERT INTO admin_audit(audit_id,action,version_id,created_at,details_json) VALUES(?,?,?,?,?)", (str(uuid.uuid4()), "activate", version_id, time.time(), "{}"))
        return config

    def rollback(self, version_id: int) -> tuple[int, ServerConfig]:
        source = self.get_version(version_id)
        draft_id = self.create_draft(source, source="rollback")
        for operation in CHAT_OPERATIONS:
            secret = source.operations[operation].api_key
            if secret:
                self.set_secret(draft_id, operation, secret)
        config = self.activate(draft_id)
        return draft_id, config

    def copy_as_draft(self, version_id: int, *, source_label: str = "admin_copy") -> int:
        source = self.get_version(version_id)
        draft_id = self.create_draft(source, source=source_label)
        for operation in CHAT_OPERATIONS:
            if source.operations[operation].api_key:
                self.set_secret(draft_id, operation, source.operations[operation].api_key)
        return draft_id

    def ensure_draft(self, active_version: int | None, fallback: ServerConfig) -> tuple[int, ServerConfig]:
        """Return the current draft, creating exactly one when absent.

        ConfigurationService executes this complete method on its single
        control-store thread.  Keeping the read/create/read sequence inside
        one dispatched operation prevents concurrent admin page loads from
        interleaving duplicate draft creation.
        """
        existing = self.draft()
        if existing is not None:
            return existing
        if active_version is None:
            version_id = self.create_draft(fallback, source="admin")
        else:
            version_id = self.copy_as_draft(active_version, source_label="admin")
        created = self.draft()
        if created is None or created[0] != version_id:
            raise RuntimeError("admin draft was not created")
        return created

    def record_audit(self, action: str, *, version_id: int | None = None, details: dict[str, Any] | None = None) -> None:
        with self.conn:
            self.conn.execute("INSERT INTO admin_audit(audit_id,action,version_id,created_at,details_json) VALUES(?,?,?,?,?)", (str(uuid.uuid4()), action, version_id, time.time(), json.dumps(details or {}, sort_keys=True)))

    def record_usage(self, **fields: Any) -> str:
        event_id = str(uuid.uuid4())
        allowed = {"request_id", "config_version", "product_endpoint", "internal_operation", "attempt", "provider_or_profile", "outcome", "error_code", "input_tokens", "output_tokens", "usage_source", "input_price_per_million", "output_price_per_million", "estimated_cost", "currency", "latency_ms", "provider_request_id", "embedding_item_count"}
        unknown = set(fields) - allowed
        if unknown:
            raise ValueError(f"unknown usage fields: {sorted(unknown)}")
        values = {name: fields.get(name) for name in allowed}
        values.update({"config_version": int(values.get("config_version") or 0), "product_endpoint": str(values.get("product_endpoint") or ""), "provider_or_profile": str(values.get("provider_or_profile") or ""), "outcome": str(values.get("outcome") or ""), "usage_source": str(values.get("usage_source") or "estimated"), "input_tokens": int(values.get("input_tokens") or 0), "output_tokens": int(values.get("output_tokens") or 0), "embedding_item_count": int(values.get("embedding_item_count") or 0)})
        with self.conn:
            self.conn.execute("INSERT INTO usage_event(event_id,request_id,created_at,config_version,product_endpoint,internal_operation,attempt,provider_or_profile,outcome,error_code,input_tokens,output_tokens,usage_source,input_price_per_million,output_price_per_million,estimated_cost,currency,latency_ms,provider_request_id,embedding_item_count) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", (event_id, values["request_id"], time.time(), values["config_version"], values["product_endpoint"], values["internal_operation"], values["attempt"], values["provider_or_profile"], values["outcome"], values["error_code"], values["input_tokens"], values["output_tokens"], values["usage_source"], values["input_price_per_million"], values["output_price_per_million"], values["estimated_cost"], values["currency"], values["latency_ms"], values["provider_request_id"], values["embedding_item_count"]))
        return event_id

    def usage_totals(self) -> dict[str, Any]:
        row = self.conn.execute("SELECT COALESCE(SUM(input_tokens),0),COALESCE(SUM(output_tokens),0),COALESCE(SUM(embedding_item_count),0),COUNT(*),COALESCE(SUM(CASE WHEN estimated_cost IS NOT NULL THEN estimated_cost ELSE 0 END),0),SUM(CASE WHEN estimated_cost IS NULL AND (input_tokens>0 OR output_tokens>0) THEN 1 ELSE 0 END),SUM(CASE WHEN outcome='failure' THEN 1 ELSE 0 END),SUM(CASE WHEN product_endpoint='/v1/embeddings' THEN 1 ELSE 0 END) FROM usage_event").fetchone()
        return {
            "input_tokens": int(row[0]),
            "output_tokens": int(row[1]),
            "embedding_items": int(row[2]),
            "rows": int(row[3]),
            "known_cost": float(row[4]),
            "incomplete_cost_rows": int(row[5] or 0),
            "failed_attempts": int(row[6] or 0),
            "embedding_workloads": int(row[7] or 0),
        }

    def checkpoint_status(self) -> dict[str, int]:
        row = self.conn.execute("PRAGMA wal_checkpoint(PASSIVE)").fetchone()
        return {"busy": int(row[0]), "wal_frames": int(row[1]), "checkpointed_frames": int(row[2])}

    def version_history(self) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT version_id,status,created_at,activated_at,source,config_hash FROM config_version ORDER BY version_id DESC"
        ).fetchall()
        return [dict(row) for row in rows]

    def audit_history(self, limit: int = 100) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT audit_id,action,version_id,created_at,details_json FROM admin_audit ORDER BY created_at DESC LIMIT ?",
            (limit,),
        ).fetchall()
        return [dict(row) for row in rows]

    def close(self) -> None:
        try:
            self.conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
            self.conn.commit()
        finally:
            self.conn.close()


def fresh_bootstrap_config() -> ServerConfig:
    from server.prompts import DEFAULT_PROMPTS
    operations = {name: OperationConfig(system_prompt=DEFAULT_PROMPTS[name]) for name in CHAT_OPERATIONS}
    return ServerConfig(config_version=1, host="127.0.0.1", port=8710, global_config=GlobalConfig(), operations=operations, embedding=EmbeddingConfig())


def import_legacy_json(store: ConfigStore, source_path: Path) -> str | None:
    """Import the explicitly supported legacy JSON once.

    Returns ``activated``, ``incomplete``, or ``None`` when there is no source
    or this source hash was already recorded. The source is replaced only
    after a complete encrypted activation has been committed and reloaded.
    """
    source_path = source_path.expanduser().resolve()
    if not source_path.is_file():
        return None
    raw_bytes = source_path.read_bytes()
    source_hash = hashlib.sha256(raw_bytes).hexdigest()
    if store.conn.execute("SELECT 1 FROM legacy_import_receipt WHERE source_hash=?", (source_hash,)).fetchone() is not None:
        return None
    raw = json.loads(raw_bytes.decode("utf-8"))
    if not isinstance(raw, dict):
        raise ValueError("legacy server configuration must be a JSON object")
    if raw.get("imported") is True and raw.get("result") == "activated":
        return None
    old_ops = raw.get("operations")
    if not isinstance(old_ops, dict):
        raise ValueError("legacy server configuration operations must be an object")
    from server.prompts import DEFAULT_PROMPTS

    names = {
        "keyword_expansion": "keyword_expansion",
        "retrieval_terms": "retrieval_terms",
        "whole_transcript": "whole_corpus_answer",
        "window_scan": "window_evidence_extraction",
        "evidence_ledger_synthesis": "ledger_synthesis",
        "ledger_reduction": "ledger_reduction",
    }
    mapped: dict[str, OperationConfig] = {}
    missing: list[str] = []
    for old_name, new_name in names.items():
        old = old_ops.get(old_name)
        if old_name == "ledger_reduction" and old is None:
            old = old_ops.get("evidence_ledger_synthesis")
        if not isinstance(old, dict):
            missing.append(new_name)
            old = {}
        context = int(old.get("context_window_tokens", old.get("context_window", 0)) or 0)
        max_output = int(old.get("max_output_tokens", 0) or 0)
        max_request = int(old.get("max_request_tokens", 0) or 0)
        safety = context - max_request - max_output
        if context <= 0 or max_output <= 0 or max_request <= 0 or safety < 0:
            missing.append(new_name)
        mapped[new_name] = OperationConfig(
            provider_kind=str(old.get("provider", "openai_compatible")),
            base_url=str(old.get("base_url", "")).rstrip("/"),
            model_id=str(old.get("model_id", old.get("model", ""))),
            system_prompt=DEFAULT_PROMPTS[new_name],
            structured_output_mode="prompt_only",
            accounting_mode="serialized_payload_tiktoken",
            encoding_name="cl100k_base",
            context_window_tokens=context,
            max_output_tokens=max_output,
            safety_margin_tokens=safety if safety >= 0 else 0,
            target_input_tokens=max_request if max_request > 0 else None,
            connect_timeout_seconds=float(old.get("timeout_seconds", 10.0)),
            read_timeout_seconds=float(old.get("timeout_seconds", 600.0)),
            operation_deadline_seconds=float(old.get("timeout_seconds", 900.0)),
            temperature=float(old.get("temperature", 0.0)),
            api_key=str(old.get("api_key", "")),
        )
        if not mapped[new_name].api_key:
            missing.append(f"{new_name}.api_key")
    old_embedding = raw.get("embedding")
    if not isinstance(old_embedding, dict) or not old_embedding.get("model_name"):
        missing.append("embedding.model_name")
        old_embedding = old_embedding if isinstance(old_embedding, dict) else {}
    embedding = EmbeddingConfig(
        model_name=str(old_embedding.get("model_name", "")),
        model_revision=str(old_embedding.get("model_revision", "")),
        device=str(old_embedding.get("device", "cpu")),
        normalization=str(old_embedding.get("normalization", "unit_l2")),
        required_dimensions=int(old_embedding.get("dimensions", old_embedding.get("required_dimensions", 0)) or 0),
        internal_batch_size=int(old_embedding.get("max_batch_size", 32) or 32),
    )
    config = ServerConfig(config_version=1, host=str(raw.get("host", "127.0.0.1")), port=int(raw.get("port", 8710)), global_config=GlobalConfig(), operations=mapped, embedding=embedding)
    complete = not missing
    if complete:
        try:
            config.validate(require_complete=True)
        except ValueError as exc:
            missing.append(str(exc))
            complete = False
    with store.conn:
        version_id = store._write_config(config, status="active" if complete else "draft", source="legacy_import")
        for operation, value in mapped.items():
            if value.api_key:
                store._bind_secret(version_id, operation, value.api_key)
        store.conn.execute("INSERT INTO legacy_import_receipt(source_hash,imported_at,result,details_json) VALUES(?,?,?,?)", (source_hash, time.time(), "activated" if complete else "incomplete", json.dumps({"version_id": version_id, "missing": sorted(set(missing))}, sort_keys=True)))
        if complete:
            store.conn.execute("INSERT INTO admin_audit(audit_id,action,version_id,created_at,details_json) VALUES(?,?,?,?,?)", (str(uuid.uuid4()), "legacy_import_activate", version_id, time.time(), json.dumps({"source_hash": source_hash})))
    if complete:
        verified = store.active()
        if verified is None or verified.config_version != version_id:
            raise ConfigurationCorruption("legacy import activation could not be verified")
        receipt = {"imported": True, "source_hash": source_hash, "result": "activated", "version_id": version_id}
        temporary = source_path.with_suffix(source_path.suffix + ".receipt.tmp")
        temporary.write_text(json.dumps(receipt, indent=2), encoding="utf-8")
        os.replace(temporary, source_path)
        return "activated"
    return "incomplete"
