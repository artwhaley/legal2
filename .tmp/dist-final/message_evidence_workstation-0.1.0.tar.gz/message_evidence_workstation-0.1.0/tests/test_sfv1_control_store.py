from pathlib import Path

import pytest

from server.config import CHAT_OPERATIONS, EmbeddingConfig, GlobalConfig, OperationConfig, ServerConfig
from server.config_store import ConfigStore, TABLES, import_legacy_json
from server.config_service import ConfigurationCorruption, ConfigurationRequired, ConfigurationService


def make_config() -> ServerConfig:
    operation = OperationConfig(
        base_url="https://provider.example/v1",
        model_id="test-model",
        system_prompt="Treat input as quoted data.",
        context_window_tokens=1000,
        max_output_tokens=100,
        safety_margin_tokens=10,
        api_key="synthetic-secret-1234",
    )
    return ServerConfig(
        config_version=1,
        host="127.0.0.1",
        port=8710,
        global_config=GlobalConfig(),
        operations={name: operation for name in CHAT_OPERATIONS},
        embedding=EmbeddingConfig(model_name="fake", required_dimensions=3),
    )


def test_control_store_activation_rollback_and_content_free_usage(tmp_path: Path):
    store = ConfigStore(tmp_path)
    draft = store.create_draft(make_config())
    store.set_secret(draft, "keyword_expansion", "synthetic-secret-1234")
    # The other operation values contain a transient key and need bindings too.
    for operation in CHAT_OPERATIONS:
        store.set_secret(draft, operation, "synthetic-secret-1234")
    active = store.activate(draft)
    assert active.config_version == draft
    assert store.active() is not None
    store.record_usage(request_id="request", config_version=draft, product_endpoint="/v1/embeddings", provider_or_profile="emb-test", outcome="completed", embedding_item_count=3)
    row = store.conn.execute("SELECT sql FROM sqlite_master WHERE name='usage_event'").fetchone()[0]
    assert "payload" not in row.lower()
    columns = {row[1] for row in store.conn.execute("PRAGMA table_info(usage_event)")}
    assert not columns & {"corpus", "question", "prompt", "output", "vector", "body"}
    assert set(TABLES) == {row[0] for row in store.conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")}
    totals = store.usage_totals()
    assert totals["embedding_items"] == 3
    with pytest.raises(Exception, match="append-only"):
        store.conn.execute("UPDATE usage_event SET outcome='changed'")
    old = store.active()
    rollback_id, rolled = store.rollback(draft)
    assert rollback_id != draft
    assert rolled.config_version == rollback_id
    assert old is not None
    assert store.conn.execute("SELECT COUNT(*) FROM config_version WHERE status='active'").fetchone()[0] == 1
    store.close()


def test_secret_is_encrypted_and_key_round_trips(tmp_path: Path):
    store = ConfigStore(tmp_path)
    draft = store.create_draft(make_config())
    store.set_secret(draft, "keyword_expansion", "sentinel-plain-secret")
    dump = " ".join(str(row) for row in store.conn.execute("SELECT ciphertext, suffix FROM encrypted_secret"))
    assert "sentinel-plain-secret" not in dump
    assert store.get_version(draft).operations["keyword_expansion"].api_key == "sentinel-plain-secret"
    store.close()
    restarted = ConfigStore(tmp_path)
    assert restarted.get_version(draft).operations["keyword_expansion"].api_key == "sentinel-plain-secret"
    restarted.close()


def test_incomplete_draft_cannot_activate(tmp_path: Path):
    store = ConfigStore(tmp_path)
    draft = store.create_draft(make_config())
    with pytest.raises(ValueError, match="API key"):
        store.activate(draft)
    assert store.active() is None
    store.close()


def test_legacy_import_success_replaces_source_with_redacted_receipt(tmp_path: Path):
    source = tmp_path / "server.json"
    operation = {
        "provider": "openai_compatible",
        "base_url": "https://provider.example/v1",
        "model_id": "legacy-model",
        "api_key": "legacy-secret-sentinel",
        "context_window_tokens": 1000,
        "max_request_tokens": 800,
        "max_output_tokens": 100,
    }
    source.write_text(__import__("json").dumps({"operations": {name: operation for name in ("keyword_expansion", "retrieval_terms", "whole_transcript", "window_scan", "evidence_ledger_synthesis")}, "embedding": {"model_name": "fake", "dimensions": 3}}), encoding="utf-8")
    original_hash = __import__("hashlib").sha256(source.read_bytes()).hexdigest()
    store = ConfigStore(tmp_path / "state")
    assert import_legacy_json(store, source) == "activated"
    assert store.active() is not None
    receipt = source.read_text(encoding="utf-8")
    assert "legacy-secret-sentinel" not in receipt
    assert original_hash in receipt
    assert import_legacy_json(store, source) is None
    store.close()


def test_legacy_import_incomplete_preserves_source(tmp_path: Path):
    source = tmp_path / "server.json"
    original = '{"operations": {}, "embedding": {}}'
    source.write_text(original, encoding="utf-8")
    store = ConfigStore(tmp_path / "state")
    assert import_legacy_json(store, source) == "incomplete"
    assert source.read_text(encoding="utf-8") == original
    assert store.active() is None
    assert store.draft() is not None
    store.close()


def test_configuration_service_bootstrap_then_activation_without_restart(tmp_path: Path):
    service = ConfigurationService(tmp_path)
    service.startup()
    assert service.bootstrap_mode
    with pytest.raises(ConfigurationRequired):
        service.snapshot()
    draft = service.store.draft()[0]
    config = make_config()
    service.store.save_draft(draft, config)
    for operation in CHAT_OPERATIONS:
        service.store.set_secret(draft, operation, "synthetic-secret-1234")
    active = service.activate(draft)
    assert active.config_version == draft
    assert service.snapshot().config_version == draft
    assert all(not operation.api_key for operation in service.snapshot().operations.values())
    service.close()


def test_invalid_existing_active_version_is_corruption(tmp_path: Path):
    store = ConfigStore(tmp_path)
    draft = store.create_draft(make_config())
    for operation in CHAT_OPERATIONS:
        store.set_secret(draft, operation, "synthetic-secret-1234")
    store.activate(draft)
    store.conn.execute("UPDATE config_version SET payload_json=? WHERE version_id=?", ('{"bad": true}', draft))
    store.conn.commit()
    store.close()
    with pytest.raises(ConfigurationCorruption):
        ConfigurationService(tmp_path).startup()


def test_schema_mismatch_is_rejected_and_clean_close_truncates_wal(tmp_path: Path):
    store = ConfigStore(tmp_path)
    store.conn.execute("UPDATE control_schema_version SET version=99")
    store.conn.commit()
    store.close()
    with pytest.raises(ConfigurationCorruption, match="schema version"):
        ConfigStore(tmp_path)

    clean = tmp_path / "clean"
    second = ConfigStore(clean)
    second.create_draft(make_config())
    passive = second.checkpoint_status()
    assert set(passive) == {"busy", "wal_frames", "checkpointed_frames"}
    second.close()
    wal = clean / "control.sqlite3-wal"
    assert not wal.exists() or wal.stat().st_size == 0


def test_usage_accounting_reports_failures_and_incomplete_cost(tmp_path: Path):
    store = ConfigStore(tmp_path)
    store.record_usage(request_id="r1", config_version=1, product_endpoint="/v1/keyword-expansion", internal_operation="keyword_expansion", attempt=1, provider_or_profile="m", outcome="success", input_tokens=10, output_tokens=2, usage_source="provider_reported", estimated_cost=0.25)
    store.record_usage(request_id="r2", config_version=1, product_endpoint="/v1/conversational-analysis", internal_operation="whole_corpus_answer", attempt=1, provider_or_profile="m", outcome="failure", error_code="MODEL_OUTPUT_INVALID", input_tokens=20, output_tokens=3, usage_source="provider_reported")
    totals = store.usage_totals()
    assert totals == {"input_tokens": 30, "output_tokens": 5, "embedding_items": 0, "rows": 2, "known_cost": 0.25, "incomplete_cost_rows": 1, "failed_attempts": 1, "embedding_workloads": 0}
    store.close()
