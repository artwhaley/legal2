"""Server-rendered loopback administration for every server-owned decision."""

from __future__ import annotations

import json
import secrets
import time
from pathlib import Path
from typing import Any

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from jinja2 import Environment, FileSystemLoader, select_autoescape

from server.config import CHAT_OPERATIONS, ServerConfig
from server.config_service import ConfigurationService
from server.contracts import (
    KeywordExpansionOutput,
    LedgerReductionOutput,
    LedgerSynthesisOutput,
    SCHEMA_REGISTRY,
    WindowEvidenceOutput,
    WholeCorpusOutput,
)
from server.embeddings import EmbeddingService
from server.model_runtime import ModelOutputInvalid, parse_model_output
from server.observability import EventSink
from server.provider import ProviderError
from server.token_accounting import (
    build_provider_payload,
    canonical_json,
    count_provider_payload,
    estimate_cost,
)


OUTPUT_MODELS = {
    "keyword_expansion": KeywordExpansionOutput,
    "retrieval_terms": KeywordExpansionOutput,
    "whole_corpus_answer": WholeCorpusOutput,
    "window_evidence_extraction": WindowEvidenceOutput,
    "ledger_reduction": LedgerReductionOutput,
    "ledger_synthesis": LedgerSynthesisOutput,
}


def _sample_message(message_id: str, text: str) -> dict[str, str]:
    return {
        "message_id": message_id,
        "thread_id": "synthetic-thread",
        "timestamp": "2026-01-01T00:00:00Z",
        "sender": "Synthetic Sender",
        "text": text,
    }


def sample_user_object(operation: str) -> dict[str, Any]:
    first = _sample_message("synthetic-message-1", "The school meeting is Tuesday.")
    second = _sample_message("synthetic-message-2", "I can attend the meeting.")
    coverage = [{
        "window_id": "w000001",
        "first_message_id": first["message_id"],
        "last_message_id": second["message_id"],
        "message_count": 2,
        "evidence_range_count": 1,
        "uncertainties": [],
    }]
    record = {
        "range_id": "r000001",
        "window_id": "w000001",
        "thread_id": "synthetic-thread",
        "start_message_id": first["message_id"],
        "end_message_id": second["message_id"],
        "summary": "A school meeting was scheduled and acknowledged.",
        "relevance": "Directly answers when the meeting was discussed.",
        "messages": [first, second],
        "uncertainties": [],
    }
    metadata = [{key: record[key] for key in ("range_id", "thread_id", "start_message_id", "end_message_id", "summary", "relevance")}]
    if operation == "keyword_expansion":
        return {"task": operation, "query": "school meeting schedule"}
    if operation == "retrieval_terms":
        return {"task": operation, "question": "When was the school meeting discussed?"}
    if operation == "whole_corpus_answer":
        return {"task": operation, "question": "When was the school meeting discussed?", "scope_id": "synthetic-scope", "messages": [first, second]}
    if operation == "window_evidence_extraction":
        return {"task": operation, "question": "When was the school meeting discussed?", "retrieval_terms": ["school meeting"], "window_id": "w000001", "messages": [first, second]}
    if operation == "ledger_reduction":
        return {"task": operation, "question": "When was the school meeting discussed?", "level": 1, "group_id": "g01-000001", "coverage_report": coverage, "records_or_summaries": [record]}
    if operation == "ledger_synthesis":
        return {"task": operation, "question": "When was the school meeting discussed?", "coverage_report": coverage, "ledger_metadata": metadata, "records_or_highest_level_summaries": [record]}
    raise ValueError(f"unknown operation {operation}")


class AdminController:
    def __init__(self, app: FastAPI, service: ConfigurationService, events: EventSink):
        self.app = app
        self.service = service
        self.events = events
        self.csrf_tokens: set[str] = set()
        self.environment = Environment(
            loader=FileSystemLoader(str(Path(__file__).with_name("templates"))),
            autoescape=select_autoescape(["html", "xml"]),
        )

    async def _draft(self) -> tuple[int, ServerConfig]:
        active = self.service.maybe_snapshot()
        from server.config_store import fresh_bootstrap_config

        return await self.service.store_call(
            "ensure_draft",
            None if active is None else active.config_version,
            fresh_bootstrap_config(),
        )

    async def context(self, *, message: str = "", error: str = "", test_output: dict[str, Any] | None = None) -> dict[str, Any]:
        token = secrets.token_urlsafe(24)
        self.csrf_tokens.add(token)
        draft_id, draft = await self._draft()
        active = self.service.maybe_snapshot()
        runtime = getattr(self.app.state, "current_runtime", None)
        resilience = runtime.resilience if runtime else None
        runtime_status = {
            "configuration": "required" if active is None else "active",
            "active_version": active.config_version if active else None,
            "listener_current": getattr(self.app.state, "listener_current", None),
            "listener_configured": f"{active.host}:{active.port}" if active else None,
            "listener_restart_required": bool(active and getattr(self.app.state, "listener_current", None) != f"{active.host}:{active.port}"),
            "embedding_reconfiguring": bool(getattr(self.app.state, "embedding_reconfiguring", False)),
            "embedding": runtime.embedding.status() if runtime else None,
            "operations": {
                name: {
                    "provider": active.operations[name].provider_kind,
                    "model": active.operations[name].model_id,
                    **(resilience.state(name) if resilience else {"circuit": "not_loaded", "in_flight": 0, "queued": 0}),
                }
                for name in CHAT_OPERATIONS
            } if active else {},
        }
        usage = await self.service.store_call("usage_totals")
        checkpoint = await self.service.store_call("checkpoint_status")
        versions = await self.service.store_call("version_history")
        audits = await self.service.store_call("audit_history", 100)
        previews: dict[str, dict[str, Any]] = {}
        for name in CHAT_OPERATIONS:
            operation = draft.operations[name]
            user = sample_user_object(name)
            wire = [
                {"role": "system", "content": operation.system_prompt},
                {"role": "user", "content": canonical_json(user)},
            ]
            try:
                previews[name] = build_provider_payload(
                    operation,
                    operation=name,
                    messages=wire,
                    user_object=user,
                    response_schema=SCHEMA_REGISTRY[name]["model_output"],
                )
                if "Authorization" in previews[name]:
                    raise RuntimeError("provider preview unexpectedly contains authorization")
            except Exception as exc:
                previews[name] = {"preview_error": str(exc)}
        return {
            "csrf_token": token,
            "message": message,
            "error": error,
            "test_output": test_output,
            "bootstrap": active is None,
            "active_version": active.config_version if active else None,
            "draft_id": draft_id,
            "config": draft.to_dict(),
            "secret_projection": await self.service.store_call("secret_projection", draft_id),
            "schemas": SCHEMA_REGISTRY,
            "previews": previews,
            "events": self.events.snapshot(),
            "metrics": self.events.dashboard_metrics(),
            "runtime_status": runtime_status,
            "usage": usage,
            "checkpoint": checkpoint,
            "versions": versions,
            "audits": audits,
            "operations": CHAT_OPERATIONS,
        }

    async def page(self, *, message: str = "", error: str = "", test_output: dict[str, Any] | None = None) -> HTMLResponse:
        context = await self.context(message=message, error=error, test_output=test_output)
        return HTMLResponse(self.environment.get_template("admin.html").render(**context))

    def check_csrf(self, token: str) -> None:
        if not token or token not in self.csrf_tokens:
            raise ValueError("invalid admin session token")
        self.csrf_tokens.remove(token)


def _coerce_form_value(old: Any, raw: str) -> Any:
    if old is None:
        return None if raw.strip().lower() in {"", "none", "null"} else float(raw)
    if isinstance(old, bool):
        return raw.lower() in {"1", "true", "yes", "on"}
    if isinstance(old, int):
        return int(raw)
    if isinstance(old, float):
        return float(raw)
    if isinstance(old, list):
        return [int(item.strip()) for item in raw.split(",") if item.strip()]
    return raw


def register_admin(app: FastAPI, service: ConfigurationService, events: EventSink) -> AdminController:
    controller = AdminController(app, service, events)

    @app.get("/admin/", response_class=HTMLResponse, include_in_schema=False)
    async def admin_page(request: Request) -> HTMLResponse:
        return await controller.page()

    @app.post("/admin/action", response_class=HTMLResponse, include_in_schema=False)
    async def admin_action(request: Request) -> HTMLResponse:
        form = await request.form()
        action = str(form.get("action", ""))
        version_id = int(form["version_id"]) if form.get("version_id") else None
        try:
            controller.check_csrf(str(form.get("csrf_token", "")))
            if action == "validate":
                if version_id is None:
                    raise ValueError("version_id is required")
                await service.store_call("validate_version", version_id)
                await service.store_call("record_audit", "validate", version_id=version_id)
                events.emit("config_validate", config_version=version_id)
                return await controller.page(message="Draft is valid; no provider or embedding call was made.")
            if action == "activate":
                if version_id is None:
                    raise ValueError("version_id is required")
                activated = await app.state.activate_runtime(version_id)
                events.emit("config_activate", config_version=activated.config_version)
                return await controller.page(message=f"Configuration {activated.config_version} activated.")
            if action == "save":
                if version_id is None:
                    raise ValueError("version_id is required")
                current = await service.store_call("get_version", version_id)
                raw = current.to_dict()
                raw["host"] = str(form.get("host", raw["host"]))
                raw["port"] = int(form.get("port", raw["port"]))
                for operation in CHAT_OPERATIONS:
                    values = dict(raw["operations"][operation])
                    for field_name, old in tuple(values.items()):
                        key = f"operations.{operation}.{field_name}"
                        if key in form:
                            values[field_name] = _coerce_form_value(old, str(form[key]))
                    raw["operations"][operation] = values
                for section in ("global_config", "embedding"):
                    values = dict(raw[section])
                    for field_name, old in tuple(values.items()):
                        key = f"{section}.{field_name}"
                        if key in form:
                            values[field_name] = _coerce_form_value(old, str(form[key]))
                    raw[section] = values
                updated = ServerConfig.from_dict(raw, config_version=version_id)
                await service.store_call("save_draft", version_id, updated)
                for operation in CHAT_OPERATIONS:
                    replacement = str(form.get(f"secret.{operation}", ""))
                    if replacement:
                        await service.store_call("set_secret", version_id, operation, replacement)
                    if str(form.get(f"remove_secret.{operation}", "")) == "on":
                        if str(form.get(f"confirm_remove.{operation}", "")) != "REMOVE":
                            raise ValueError(f"type REMOVE to confirm removal of {operation} secret")
                        await service.store_call("set_secret", version_id, operation, "", remove=True)
                await service.store_call("record_audit", "save", version_id=version_id)
                events.emit("config_save", config_version=version_id)
                return await controller.page(message="Draft saved. Active runtime is unchanged.")
            if action == "test":
                if version_id is None:
                    raise ValueError("version_id is required")
                operation_name = str(form.get("operation", ""))
                if operation_name not in CHAT_OPERATIONS:
                    raise ValueError("operation is required")
                draft = await service.store_call("get_version", version_id)
                operation = draft.operations[operation_name]
                operation.validate(operation_name, require_secret=True)
                user = sample_user_object(operation_name)
                schema = SCHEMA_REGISTRY[operation_name]["model_output"]
                wire = [
                    {"role": "system", "content": operation.system_prompt},
                    {"role": "user", "content": canonical_json(user)},
                ]
                payload = build_provider_payload(operation, operation=operation_name, messages=wire, user_object=user, response_schema=schema)
                accounting = count_provider_payload(payload, operation)
                if not accounting.fits:
                    raise ValueError("synthetic operation test does not fit the draft budget")
                provider = getattr(app.state, "provider", None)
                if provider is None:
                    raise RuntimeError("provider transport is not started")
                started = time.perf_counter()
                try:
                    result = await provider.chat(operation_name, operation, messages=wire, user_object=user, response_schema=schema, api_key=operation.api_key)
                except ProviderError as exc:
                    latency_ms = (time.perf_counter() - started) * 1000
                    cost = estimate_cost(operation, accounting.input_tokens, 0)
                    await service.store_call("record_usage", request_id=None, config_version=version_id, product_endpoint="/admin/test", internal_operation=operation_name, attempt=1, provider_or_profile=operation.model_id, outcome="failure", error_code=exc.code, input_tokens=accounting.input_tokens, output_tokens=0, usage_source="estimated", input_price_per_million=operation.input_price_per_million, output_price_per_million=operation.output_price_per_million, estimated_cost=cost, currency="USD", latency_ms=latency_ms, provider_request_id=exc.provider_request_id)
                    await service.store_call("record_audit", "test_failed", version_id=version_id, details={"operation": operation_name, "error_code": exc.code})
                    events.emit("config_test_failed", config_version=version_id, internal_operation=operation_name, error_code=exc.code, latency_ms=latency_ms, severity="ERROR")
                    return await controller.page(
                        error=str(exc),
                        test_output={
                            "operation": operation_name,
                            "schema_valid": False,
                            "accounted_input_tokens": accounting.input_tokens,
                            "provider_input_tokens": None,
                            "provider_output_tokens": None,
                            "usage_source": "estimated",
                            "latency_ms": latency_ms,
                            "estimated_cost": cost,
                            "raw_output": None,
                            "parsed_output": None,
                            "error_code": exc.code,
                        },
                    )
                try:
                    parsed = parse_model_output(result.content, OUTPUT_MODELS[operation_name])
                except ModelOutputInvalid as exc:
                    cost = estimate_cost(operation, result.input_tokens, result.output_tokens)
                    await service.store_call("record_usage", request_id=None, config_version=version_id, product_endpoint="/admin/test", internal_operation=operation_name, attempt=1, provider_or_profile=operation.model_id, outcome="failure", error_code=exc.code, input_tokens=result.input_tokens, output_tokens=result.output_tokens, usage_source=result.usage_source, input_price_per_million=operation.input_price_per_million, output_price_per_million=operation.output_price_per_million, estimated_cost=cost, currency="USD", latency_ms=result.latency_ms, provider_request_id=result.provider_request_id)
                    await service.store_call("record_audit", "test_failed", version_id=version_id, details={"operation": operation_name, "error_code": exc.code})
                    events.emit("config_test_failed", config_version=version_id, internal_operation=operation_name, error_code=exc.code, latency_ms=result.latency_ms, severity="ERROR")
                    return await controller.page(
                        error=str(exc),
                        test_output={
                            "operation": operation_name,
                            "schema_valid": False,
                            "accounted_input_tokens": accounting.input_tokens,
                            "provider_input_tokens": result.input_tokens,
                            "provider_output_tokens": result.output_tokens,
                            "usage_source": result.usage_source,
                            "latency_ms": result.latency_ms,
                            "estimated_cost": cost,
                            "raw_output": result.content,
                            "parsed_output": None,
                            "error_code": exc.code,
                        },
                    )
                cost = estimate_cost(operation, result.input_tokens, result.output_tokens)
                await service.store_call("record_usage", request_id=None, config_version=version_id, product_endpoint="/admin/test", internal_operation=operation_name, attempt=1, provider_or_profile=operation.model_id, outcome="success", input_tokens=result.input_tokens, output_tokens=result.output_tokens, usage_source=result.usage_source, input_price_per_million=operation.input_price_per_million, output_price_per_million=operation.output_price_per_million, estimated_cost=cost, currency="USD", latency_ms=result.latency_ms, provider_request_id=result.provider_request_id)
                await service.store_call("record_audit", "test", version_id=version_id, details={"operation": operation_name})
                events.emit("config_test", config_version=version_id, internal_operation=operation_name, latency_ms=result.latency_ms)
                return await controller.page(
                    message=f"Strict test passed for {operation_name}.",
                    test_output={
                        "operation": operation_name,
                        "schema_valid": True,
                        "accounted_input_tokens": accounting.input_tokens,
                        "provider_input_tokens": result.input_tokens,
                        "provider_output_tokens": result.output_tokens,
                        "usage_source": result.usage_source,
                        "latency_ms": result.latency_ms,
                        "estimated_cost": cost,
                        "raw_output": result.content,
                        "parsed_output": parsed.model_dump(),
                    },
                )
            if action == "test_embedding":
                if version_id is None:
                    raise ValueError("version_id is required")
                draft = await service.store_call("get_version", version_id)
                draft.embedding.validate(require_model=True)
                candidate = app.state.embedding_factory(draft.embedding)
                try:
                    profile = await candidate.prepare()
                    vectors = await candidate.encode(["synthetic embedding test"])
                    if len(vectors) != 1 or len(vectors[0]) != profile.dimensions or any(not isinstance(value, float) for value in vectors[0]):
                        raise RuntimeError("embedding test returned invalid dimensions or values")
                finally:
                    await candidate.close_async()
                await service.store_call("record_audit", "test_embedding", version_id=version_id)
                events.emit("embedding_config_test", config_version=version_id, model=draft.embedding.model_name)
                return await controller.page(message=f"Embedding test passed: {profile.profile_id}, {profile.dimensions} dimensions.")
            if action == "rollback":
                source_version = int(form.get("source_version", "0"))
                if source_version <= 0:
                    raise ValueError("rollback source version is required")
                draft_id = await service.store_call("copy_as_draft", source_version, source_label="rollback")
                activated = await app.state.activate_runtime(draft_id)
                await service.store_call("record_audit", "rollback", version_id=activated.config_version, details={"source_version": source_version})
                events.emit("config_rollback", config_version=activated.config_version)
                return await controller.page(message=f"Version {source_version} rolled forward as active version {activated.config_version}.")
            if action == "reset_circuit":
                operation_name = str(form.get("operation", ""))
                runtime = getattr(app.state, "current_runtime", None)
                if runtime is None or operation_name not in CHAT_OPERATIONS:
                    raise ValueError("active operation is required")
                runtime.resilience.reset_circuit(operation_name)
                await service.store_call("record_audit", "reset_circuit", version_id=runtime.config.config_version, details={"operation": operation_name})
                events.emit("circuit_reset", config_version=runtime.config.config_version, internal_operation=operation_name)
                return await controller.page(message=f"Circuit reset for {operation_name}.")
            raise ValueError(f"unsupported admin action {action}")
        except Exception as exc:
            events.emit("admin_action_failed", internal_operation=action or None, error_code=getattr(exc, "code", exc.__class__.__name__), severity="ERROR")
            return await controller.page(error=str(exc))

    @app.get("/admin/events", include_in_schema=False)
    async def admin_events() -> dict[str, Any]:
        runtime = getattr(app.state, "current_runtime", None)
        return {
            "events": events.snapshot(),
            "metrics": events.dashboard_metrics(),
            "usage": await service.store_call("usage_totals"),
            "embedding": runtime.embedding.status() if runtime else None,
        }

    return controller
