"""Local EVW workflows and the stateless remote gateway boundary."""

from __future__ import annotations

import hashlib
import math
import sqlite3
import struct
import uuid
from dataclasses import dataclass
from typing import Any, Callable, Iterator

from message_evidence_workstation.client_api.gateway import RemoteGateway, RemoteGatewayError
from message_evidence_workstation.db.corpus_repository import WorkingCorpusRepository
from message_evidence_workstation.db.workspace_store import WorkspaceStore
from message_evidence_workstation.domain.search_scope import NarrowedSearchScope, WorkingCorpusScope
from message_evidence_workstation.logging_ui.diagnostic_logger import DiagnosticLogger, utc_now_iso
from message_evidence_workstation.search.scoped_search import search_fts, search_keyword_terms


@dataclass(frozen=True, slots=True)
class EmbeddingBuildResult:
    required_inputs: int
    reused_artifacts: int
    generated_artifacts: int
    dimensions: int
    normalization: str
    granularity: str = "message"

    @property
    def message_count(self) -> int:
        return self.required_inputs

    @property
    def chunk_count(self) -> int:
        return self.required_inputs if self.granularity == "chunk" else 0


@dataclass(frozen=True, slots=True)
class EmbeddingBuildProgress:
    phase: str
    completed: int
    total: int
    batch_number: int
    batch_count: int
    message: str


@dataclass(frozen=True, slots=True)
class EmbeddingCacheClearResult:
    artifacts_deleted: int
    revision_indexes_marked_missing: int


@dataclass(frozen=True, slots=True)
class ConversationalSearchProgress:
    phase: str
    completed: int
    total: int
    message: str


@dataclass(frozen=True, slots=True)
class ConversationalExecutionResult:
    result: dict[str, Any]
    persistence_warning: str | None = None


class StaleConversationScope(RuntimeError):
    pass


def _blob(vector: list[float]) -> bytes:
    return struct.pack("<" + "f" * len(vector), *(float(value) for value in vector))


def _hash_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _require_scope(conn: sqlite3.Connection, scope: WorkingCorpusScope) -> None:
    WorkingCorpusRepository(conn).validate_ready_scope(scope)


class ClientWorkflowService:
    def __init__(self, conn: sqlite3.Connection, logger: DiagnosticLogger | None, gateway: RemoteGateway) -> None:
        self.conn, self.logger, self.gateway = conn, logger, gateway

    def fts5_search(self, scope: NarrowedSearchScope, query: str, *, limit: int = 200, offset: int = 0) -> dict[str, Any]:
        return _page_dict(search_fts(self.conn, self.logger, scope, query, limit=limit, offset=offset))

    def keyword_terms_search(self, scope: NarrowedSearchScope, terms: list[str], *, limit: int = 200) -> dict[str, Any]:
        return _page_dict(search_keyword_terms(self.conn, self.logger, scope, terms, limit=limit))

    def embedding_search_with_vector(self, scope: NarrowedSearchScope, vector: list[float], dimensions: int, *, top_k: int = 20, granularity: str = "message") -> list[dict[str, Any]]:
        _require_scope(self.conn, scope.working_corpus)
        if granularity not in {"message", "chunk"}:
            raise ValueError("granularity must be message or chunk")
        required_status = "message_embedding_status" if granularity == "message" else "chunk_embedding_status"
        row = self.conn.execute("SELECT message_embedding_status,chunk_embedding_status FROM working_corpus_revision_index WHERE working_corpus_revision_id=? AND index_generation=?", (scope.working_corpus_revision_id, scope.index_generation)).fetchone()
        state = self.conn.execute("SELECT dimensions FROM embedding_cache_state WHERE cache_id=1").fetchone()
        if row is None or str(row[required_status]) != "ready":
            raise RuntimeError(f"{granularity} embedding index is not ready")
        if state is None or int(state[0]) != dimensions:
            raise RuntimeError("EMBEDDING_CACHE_GEOMETRY_MISMATCH")
        query_blob = _blob(vector)
        import sqlite_vec
        self.conn.enable_load_extension(True)
        sqlite_vec.load(self.conn)
        if granularity == "message":
            rows = self.conn.execute(
                """SELECT m.message_id,m.source_thread_id,m.timestamp,m.body,
                          vec_distance_L2(e.vector, ?) AS distance
                     FROM working_corpus_revision_message wcrm
                     JOIN message m ON m.message_id=wcrm.message_id
                     JOIN embedding_artifact e ON e.input_hash=wcrm.embedding_input_hash
                    WHERE wcrm.working_corpus_revision_id=?
                    ORDER BY distance,m.timestamp,m.sort_index,m.message_id LIMIT ?""",
                (query_blob, scope.working_corpus_revision_id, top_k),
            ).fetchall()
            return [{"message_id": str(r["message_id"]), "source_thread_id": str(r["source_thread_id"]), "timestamp": str(r["timestamp"]), "body": str(r["body"]), "distance": float(r["distance"])} for r in rows]
        rows = self.conn.execute(
            """SELECT c.chunk_id,c.source_thread_id,c.start_message_id,c.end_message_id,c.body_text,
                      vec_distance_L2(e.vector, ?) AS distance
                 FROM message_chunk c JOIN embedding_artifact e ON e.input_hash=c.embedding_input_hash
                WHERE c.working_corpus_revision_id=? AND c.index_generation=?
                ORDER BY distance,c.chunk_id LIMIT ?""",
            (query_blob, scope.working_corpus_revision_id, scope.index_generation, top_k),
        ).fetchall()
        return [{"chunk_id": int(r["chunk_id"]), "source_thread_id": str(r["source_thread_id"]), "start_message_id": str(r["start_message_id"]), "end_message_id": str(r["end_message_id"]), "body_text": str(r["body_text"]), "distance": float(r["distance"])} for r in rows]


def _page_dict(page: Any) -> dict[str, Any]:
    return {"hits": [{"message_id": h.message_id, "source_thread_id": h.source_thread_id, "match_type": h.match_type, "rank": h.rank} for h in page.hits], "total_count": page.total_count, "has_more": page.has_more, "next_offset": page.next_offset, "invalid_query_reason": page.invalid_query_reason}


class KeywordSearchWorkflow:
    def __init__(self, store: WorkspaceStore, logger: DiagnosticLogger, gateway: RemoteGateway) -> None:
        self.store, self.logger, self.gateway = store, logger, gateway

    def execute(self, scope: NarrowedSearchScope, query: str, *, limit: int = 200) -> dict[str, Any]:
        if not query.strip():
            raise ValueError("Keyword search requires a query")
        terms = list(self.gateway.keyword_expansion(query))
        result = self.store.read(lambda conn: ClientWorkflowService(conn, self.logger, self.gateway).keyword_terms_search(scope, terms, limit=limit))
        result["terms"] = terms
        return result


def _ensure_chunks(conn: sqlite3.Connection, scope: WorkingCorpusScope) -> None:
    if conn.execute("SELECT 1 FROM message_chunk WHERE working_corpus_revision_id=? AND index_generation=? LIMIT 1", (scope.working_corpus_revision_id, scope.index_generation)).fetchone() is not None:
        return
    rows = conn.execute(
        """SELECT m.message_id,m.source_thread_id,m.timestamp,m.sender_display,m.body
             FROM working_corpus_revision_message w JOIN message m ON m.message_id=w.message_id
            WHERE w.working_corpus_revision_id=? ORDER BY w.ordinal""",
        (scope.working_corpus_revision_id,),
    ).fetchall()
    batch: list[sqlite3.Row] = []
    chars = 0
    for row in rows:
        text = f"[{row['timestamp']}] {row['sender_display']}: {row['body']}"
        if batch and (row["source_thread_id"] != batch[0]["source_thread_id"] or len(batch) >= 40 or chars + len(text) > 12000):
            _insert_chunk(conn, scope, batch)
            batch = []
            chars = 0
        batch.append(row)
        chars += len(text)
    if batch:
        _insert_chunk(conn, scope, batch)


def _insert_chunk(conn: sqlite3.Connection, scope: WorkingCorpusScope, rows: list[sqlite3.Row]) -> None:
    body = "\n".join(f"[{row['timestamp']}] {row['sender_display']}: {row['body']}" for row in rows)
    conn.execute(
        """INSERT INTO message_chunk(working_corpus_revision_id,index_generation,source_thread_id,start_message_id,end_message_id,message_count,char_count,text_checksum,embedding_input_hash,body_text)
           VALUES (?,?,?,?,?,?,?,?,?,?)""",
        (scope.working_corpus_revision_id, scope.index_generation, rows[0]["source_thread_id"], rows[0]["message_id"], rows[-1]["message_id"], len(rows), len(body), _hash_text(body), _hash_text(body), body),
    )


class EmbeddingBuildCoordinator:
    def __init__(self, store: WorkspaceStore, logger: DiagnosticLogger, gateway: RemoteGateway) -> None:
        self.store, self.logger, self.gateway = store, logger, gateway

    def _all_items(self, conn: sqlite3.Connection, scope: WorkingCorpusScope, granularity: str) -> list[dict[str, str]]:
        if granularity == "chunk":
            _ensure_chunks(conn, scope)
            rows = conn.execute("SELECT DISTINCT embedding_input_hash,body_text FROM message_chunk WHERE working_corpus_revision_id=? AND index_generation=? ORDER BY chunk_id", (scope.working_corpus_revision_id, scope.index_generation)).fetchall()
            return [{"message_id": f"cache:{row['embedding_input_hash']}", "text": str(row["body_text"])} for row in rows]
        rows = conn.execute("SELECT DISTINCT wcrm.embedding_input_hash,m.body FROM working_corpus_revision_message wcrm JOIN message m ON m.message_id=wcrm.message_id WHERE wcrm.working_corpus_revision_id=? ORDER BY wcrm.ordinal", (scope.working_corpus_revision_id,)).fetchall()
        return [{"message_id": f"cache:{row['embedding_input_hash']}", "text": str(row["body"])} for row in rows]

    def build(self, scope: WorkingCorpusScope, progress: Callable[[EmbeddingBuildProgress], None] | None = None, *, granularity: str = "message") -> EmbeddingBuildResult:
        if granularity not in {"message", "chunk"}:
            raise ValueError("granularity must be message or chunk")
        self.store.read(lambda conn: _require_scope(conn, scope))
        report = progress or (lambda _value: None)
        all_items = self.store.write(lambda conn: self._all_items(conn, scope, granularity))
        if not all_items:
            raise ValueError("working corpus revision contains no messages")
        hashes = {item["message_id"][len("cache:"):] for item in all_items}
        existing = self.store.read(lambda conn: {str(row[0]) for row in conn.execute("SELECT input_hash FROM embedding_artifact WHERE input_hash IN ({})".format(",".join("?" for _ in hashes)), tuple(hashes)).fetchall()} if hashes else set())
        pending = [item for item in all_items if item["message_id"][len("cache:"):] not in existing]
        state = self.store.read(lambda conn: conn.execute("SELECT dimensions,normalization FROM embedding_cache_state WHERE cache_id=1").fetchone())
        if not pending:
            if state is None:
                raise RuntimeError("embedding cache has coverage but no geometry")
            self.store.write(self._mark_ready, scope, granularity)
            return EmbeddingBuildResult(len(all_items), len(existing), 0, int(state[0]), str(state[1]), granularity)
        report(EmbeddingBuildProgress("submitting", 0, len(pending), 0, 0, f"Submitting {len(pending):,} cache misses"))
        events = self.gateway.embeddings(pending)
        accepted = next(events).value["data"]
        dimensions = int(accepted["dimensions"])
        normalization = str(accepted["normalization"])
        if state is not None and (int(state[0]) != dimensions or str(state[1]) != normalization):
            raise RuntimeError("EMBEDDING_CACHE_GEOMETRY_MISMATCH: clear local embeddings before changing embedding configuration")
        submitted = {item["message_id"] for item in pending}
        completed = 0
        batch_number = 0
        batch_count = 0
        try:
            for event in events:
                value = event.value
                if value["event"] == "embedding_batch_started":
                    batch_number = int(value["data"]["batch_index"]) + 1
                    batch_count = int(value["data"]["batch_count"])
                    report(EmbeddingBuildProgress("encoding", completed, len(pending), batch_number, batch_count, f"Server encoding batch {batch_number:,}/{batch_count:,}"))
                if value["event"] == "vector_batch":
                    vectors = value["data"]["items"]
                    if len({item["message_id"] for item in vectors}) != len(vectors) or any(item["message_id"] not in submitted or len(item["vector"]) != dimensions or any(not math.isfinite(float(n)) for n in item["vector"]) for item in vectors):
                        raise RuntimeError("server returned an invalid vector batch")
                    self.store.write(self._commit_vectors, vectors, dimensions, normalization)
                    completed += len(vectors)
                    report(EmbeddingBuildProgress("committed", completed, len(pending), batch_number, batch_count, f"Committed {completed:,}/{len(pending):,} vectors"))
                if value["event"] == "failed":
                    raise RemoteGatewayError(str(value["error"]["message"]), error_code=str(value["error"]["code"]))
                if value["event"] == "completed":
                    if int(value["result"]["total_items"]) != len(pending) or completed != len(pending):
                        raise RuntimeError("embedding terminal counts do not match committed vectors")
                    self.store.write(self._mark_ready, scope, granularity)
                    return EmbeddingBuildResult(len(all_items), len(existing), completed, dimensions, normalization, granularity)
            raise RemoteGatewayError("embedding stream ended without completion", interrupted=True)
        except Exception as exc:
            self.store.write(self._mark_failed, scope, granularity, str(exc))
            raise

    @staticmethod
    def _commit_vectors(conn: sqlite3.Connection, vectors: list[dict[str, Any]], dimensions: int, normalization: str) -> None:
        now = utc_now_iso()
        state = conn.execute("SELECT dimensions,normalization FROM embedding_cache_state WHERE cache_id=1").fetchone()
        if state is None:
            conn.execute("INSERT INTO embedding_cache_state(cache_id,dimensions,normalization,created_at,updated_at) VALUES (1,?,?,?,?)", (dimensions, normalization, now, now))
        elif int(state[0]) != dimensions or str(state[1]) != normalization:
            raise RuntimeError("EMBEDDING_CACHE_GEOMETRY_MISMATCH")
        for item in vectors:
            input_hash = str(item["message_id"])[len("cache:"):]
            blob = _blob([float(v) for v in item["vector"]])
            existing = conn.execute("SELECT dimensions,vector FROM embedding_artifact WHERE input_hash=?", (input_hash,)).fetchone()
            if existing is not None and (int(existing[0]) != dimensions or bytes(existing[1]) != blob):
                raise RuntimeError(f"Conflicting embedding artifact for {input_hash}")
            if existing is None:
                conn.execute("INSERT INTO embedding_artifact(input_hash,dimensions,vector,created_at) VALUES (?,?,?,?)", (input_hash, dimensions, blob, now))

    @staticmethod
    def _mark_ready(conn: sqlite3.Connection, scope: WorkingCorpusScope, granularity: str) -> None:
        if granularity == "chunk":
            row = conn.execute("SELECT COUNT(*) AS required,COUNT(e.input_hash) AS covered FROM message_chunk w JOIN embedding_artifact e ON e.input_hash=w.embedding_input_hash WHERE w.working_corpus_revision_id=? AND w.index_generation=?", (scope.working_corpus_revision_id, scope.index_generation)).fetchone()
            column = "chunk_embedding_status"
            error_column = "chunk_embedding_last_error"
        else:
            row = conn.execute("SELECT COUNT(*) AS required,COUNT(e.input_hash) AS covered FROM working_corpus_revision_message w JOIN embedding_artifact e ON e.input_hash=w.embedding_input_hash WHERE w.working_corpus_revision_id=?", (scope.working_corpus_revision_id,)).fetchone()
            column = "message_embedding_status"
            error_column = "message_embedding_last_error"
        if int(row["required"]) != int(row["covered"]):
            raise RuntimeError(f"embedding coverage incomplete: {row['covered']}/{row['required']}")
        conn.execute(f"UPDATE working_corpus_revision_index SET {column}='ready',{error_column}=NULL WHERE working_corpus_revision_id=? AND index_generation=?", (scope.working_corpus_revision_id, scope.index_generation))

    @staticmethod
    def _mark_failed(conn: sqlite3.Connection, scope: WorkingCorpusScope, granularity: str, error: str) -> None:
        column = "chunk_embedding_status" if granularity == "chunk" else "message_embedding_status"
        error_column = "chunk_embedding_last_error" if granularity == "chunk" else "message_embedding_last_error"
        conn.execute(f"UPDATE working_corpus_revision_index SET {column}='failed',{error_column}=? WHERE working_corpus_revision_id=? AND index_generation=?", (error, scope.working_corpus_revision_id, scope.index_generation))


class EmbeddingSearchWorkflow:
    def __init__(self, store: WorkspaceStore, logger: DiagnosticLogger, gateway: RemoteGateway) -> None:
        self.store, self.logger, self.gateway = store, logger, gateway

    def execute(self, scope: NarrowedSearchScope, query: str, *, top_k: int = 20, granularity: str = "message") -> list[dict[str, Any]]:
        if not query.strip():
            raise ValueError("Embedding search requires a query")
        state = self.store.read(lambda conn: self._state(conn, scope, granularity))
        events = self.gateway.embeddings([{"message_id": "query", "text": query}])
        accepted = next(events).value["data"]
        dimensions = int(accepted["dimensions"])
        if dimensions != state["dimensions"] or str(accepted["normalization"]) != state["normalization"]:
            raise RuntimeError("EMBEDDING_CACHE_GEOMETRY_MISMATCH")
        vector: list[float] | None = None
        terminal = None
        for event in events:
            if event.event == "vector_batch":
                items = event.value["data"]["items"]
                if len(items) != 1 or items[0]["message_id"] != "query":
                    raise RemoteGatewayError("query embedding stream returned the wrong identity")
                vector = [float(v) for v in items[0]["vector"]]
            if event.terminal:
                terminal = event.value
        if terminal is None or terminal["event"] != "completed" or vector is None:
            raise RemoteGatewayError("query embedding did not complete")
        return self.store.read(lambda conn: ClientWorkflowService(conn, self.logger, self.gateway).embedding_search_with_vector(scope, vector, dimensions, top_k=top_k, granularity=granularity))

    @staticmethod
    def _state(conn: sqlite3.Connection, scope: NarrowedSearchScope, granularity: str) -> dict[str, Any]:
        if granularity not in {"message", "chunk"}:
            raise ValueError("granularity must be message or chunk")
        _require_scope(conn, scope.working_corpus)
        status = "message_embedding_status" if granularity == "message" else "chunk_embedding_status"
        row = conn.execute(f"SELECT {status} FROM working_corpus_revision_index WHERE working_corpus_revision_id=? AND index_generation=?", (scope.working_corpus_revision_id, scope.index_generation)).fetchone()
        state = conn.execute("SELECT dimensions,normalization FROM embedding_cache_state WHERE cache_id=1").fetchone()
        if row is None or str(row[0]) != "ready" or state is None:
            raise RuntimeError(f"{granularity} embedding index is not ready")
        return {"dimensions": int(state[0]), "normalization": str(state[1])}


class EmbeddingCacheService:
    @staticmethod
    def clear_local_embeddings(conn: sqlite3.Connection) -> EmbeddingCacheClearResult:
        artifacts = int(conn.execute("SELECT COUNT(*) FROM embedding_artifact").fetchone()[0])
        affected = int(conn.execute("SELECT COUNT(*) FROM working_corpus_revision_index WHERE message_embedding_status<>'missing' OR chunk_embedding_status<>'missing' OR message_embedding_last_error IS NOT NULL OR chunk_embedding_last_error IS NOT NULL").fetchone()[0])
        conn.execute("DELETE FROM embedding_artifact")
        conn.execute("DELETE FROM embedding_cache_state")
        conn.execute("UPDATE working_corpus_revision_index SET message_embedding_status='missing',chunk_embedding_status='missing',message_embedding_last_error=NULL,chunk_embedding_last_error=NULL")
        return EmbeddingCacheClearResult(artifacts, affected)


def clear_local_embeddings(store: WorkspaceStore) -> EmbeddingCacheClearResult:
    return store.write(EmbeddingCacheService.clear_local_embeddings)


class ConversationalWorkflow:
    def __init__(self, store: WorkspaceStore, logger: DiagnosticLogger, gateway: RemoteGateway) -> None:
        self.store, self.logger, self.gateway = store, logger, gateway

    def execute(self, scope: NarrowedSearchScope, question: str, progress: Callable[[ConversationalSearchProgress], None] | None = None) -> ConversationalExecutionResult:
        if not question.strip():
            raise ValueError("Conversational search requires a question")
        messages = self.store.read(lambda conn: self._messages(conn, scope))
        if not messages:
            raise RuntimeError("WORKING_CORPUS_EMPTY")
        report = progress or (lambda _value: None)
        report(ConversationalSearchProgress("submitting", 0, 1, f"Submitting {len(messages):,} scoped messages"))
        result: dict[str, Any] | None = None
        window_total = 1
        for event in self.gateway.conversational_analysis(question=question, scope_id=self._remote_scope_id(scope.working_corpus), messages=messages):
            if event.event == "failed":
                raise RemoteGatewayError(str(event.value["error"]["message"]), error_code=str(event.value["error"]["code"]))
            if event.event == "completed":
                result = dict(event.value["result"])
                continue
            data = event.value.get("data", {})
            if event.event == "window_plan_created":
                window_total = int(data.get("window_count", 1))
            completed = int(data.get("window_index", -1)) + 1 if event.event == "window_completed" else int(data.get("window_index", -1)) if event.event == "window_started" else 0
            report(ConversationalSearchProgress(event.event, completed, window_total, f"Server: {event.event}"))
        if result is None:
            raise RemoteGatewayError("conversation stream ended without completion", interrupted=True)
        self.store.write(self._persist_visible_result, scope, question, result)
        report(ConversationalSearchProgress("completed", 1, 1, "Conversational search completed"))
        return ConversationalExecutionResult(result)

    @staticmethod
    def _remote_scope_id(scope: WorkingCorpusScope) -> str:
        return f"evw15:{scope.working_corpus_id}:{scope.working_corpus_revision_id}:{scope.index_generation}:{scope.scope_hash}"

    @staticmethod
    def _messages(conn: sqlite3.Connection, scope: NarrowedSearchScope) -> list[dict[str, str]]:
        _require_scope(conn, scope.working_corpus)
        predicate, params = scope.sql_predicate(message_alias="m")
        rows = conn.execute(f"SELECT m.message_id,m.source_thread_id,m.timestamp,m.sender_display,m.body FROM message m WHERE m.dataset_id=? AND {predicate} ORDER BY m.timestamp,m.sort_index,m.message_id", (scope.dataset_id, *params)).fetchall()
        return [{"message_id": str(r["message_id"]), "thread_id": str(r["source_thread_id"]), "timestamp": str(r["timestamp"]), "sender": str(r["sender_display"]), "text": str(r["body"])} for r in rows]

    @staticmethod
    def _persist_visible_result(conn: sqlite3.Connection, scope: NarrowedSearchScope, prompt: str, result: dict[str, Any]) -> None:
        repo = WorkingCorpusRepository(conn)
        repo.validate_ready_scope(scope.working_corpus)
        now = utc_now_iso()
        conversation_id = int(conn.execute("INSERT INTO conversation(dataset_id,working_corpus_id,working_corpus_revision_id,index_generation,scope_hash,created_at) VALUES (?,?,?,?,?,?)", (scope.dataset_id, scope.working_corpus_id, scope.working_corpus_revision_id, scope.index_generation, scope.working_corpus.scope_hash, now)).lastrowid)
        turn_id = int(conn.execute("INSERT INTO conversation_turn(conversation_id,working_corpus_id,working_corpus_revision_id,index_generation,scope_hash,user_prompt,presented_answer,mode,created_at) VALUES (?,?,?,?,?,?,?,?,?)", (conversation_id, scope.working_corpus_id, scope.working_corpus_revision_id, scope.index_generation, scope.working_corpus.scope_hash, prompt, str(result.get("answer", "")), str(result.get("strategy", "conversation")), now)).lastrowid)
        for item in result.get("evidence_ranges", result.get("evidence_ledger", [])) or []:
            message_id = item.get("start_message_id")
            if message_id and conn.execute("SELECT 1 FROM working_corpus_revision_message WHERE working_corpus_revision_id=? AND message_id=?", (scope.working_corpus_revision_id, message_id)).fetchone():
                conn.execute("INSERT INTO conversation_citation(conversation_turn_id,message_id,citation_type) VALUES (?,?,?)", (turn_id, message_id, "range_start"))
