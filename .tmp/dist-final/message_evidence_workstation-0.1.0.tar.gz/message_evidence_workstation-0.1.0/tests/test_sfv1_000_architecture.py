"""Temporary SFV1-000 route inventory; expected to fail until SFV1-500/511/600."""

from fastapi.routing import APIRoute

from server.app import create_app


def test_sfv1_target_product_routes_are_exactly_three():
    app = create_app()
    routes = {
        (method, route.path)
        for route in app.routes
        if isinstance(route, APIRoute)
        for method in route.methods
        if route.path.startswith("/v1/")
    }
    assert routes == {
        ("POST", "/v1/keyword-expansion"),
        ("POST", "/v1/conversational-analysis"),
        ("POST", "/v1/embeddings"),
    }
