"""Transport-only validation for the temporary Python client."""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any


CONVERSATION_EVENTS = {
    "accepted", "queued", "retry_wait", "accounting_completed", "whole_started",
    "whole_completed", "retrieval_terms_started", "retrieval_terms_completed",
    "window_plan_created", "window_started", "window_completed", "ledger_built",
    "ledger_reduction_started", "ledger_reduction_completed",
    "ledger_synthesis_started", "ledger_synthesis_completed", "completed", "failed",
}
EMBEDDING_EVENTS = {
    "accepted", "queued", "embedding_batch_started", "vector_batch",
    "embedding_progress", "completed", "failed",
}


def _int(value: Any) -> bool:
    return isinstance(value, int) and not isinstance(value, bool)


def _number(value: Any) -> bool:
    return (isinstance(value, int) and not isinstance(value, bool)) or isinstance(value, float)


def _exact(value: Any, keys: set[str], label: str) -> dict[str, Any]:
    if not isinstance(value, dict) or set(value) != keys:
        raise ValueError(f"{label} fields do not match the stream contract")
    return value


def validate_stream_value(value: Any, *, endpoint: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ValueError("stream event must be an object")
    event = value.get("event")
    allowed = CONVERSATION_EVENTS if endpoint == "/v1/conversational-analysis" else EMBEDDING_EVENTS if endpoint == "/v1/embeddings" else None
    if allowed is None or event not in allowed:
        raise ValueError("stream event is not valid for this endpoint")
    terminal = event in {"completed", "failed"}
    payload_key = "error" if event == "failed" else "result" if event == "completed" else "data"
    _exact(value, {"request_id", "sequence", "event", "timestamp", "config_version", payload_key}, "event envelope")
    if not isinstance(value["request_id"], str) or not value["request_id"] or not _int(value["sequence"]) or value["sequence"] < 1 or not isinstance(value["timestamp"], str) or not _int(value["config_version"]) or value["config_version"] < 1:
        raise ValueError("stream envelope has invalid scalar fields")
    payload = value[payload_key]
    if event == "failed":
        error = _exact(payload, {"request_id", "code", "message", "stage", "retryable", "details"}, "failed error")
        if error["request_id"] != value["request_id"] or any(not isinstance(error[key], str) or not error[key] for key in ("code", "message", "stage")) or not isinstance(error["retryable"], bool) or not isinstance(error["details"], dict):
            raise ValueError("failed error has invalid fields")
    elif event == "accepted":
        if endpoint == "/v1/embeddings":
            data = _exact(payload, {"endpoint", "total_items", "embedding_profile_id", "model", "requested_revision", "artifact_fingerprint", "dimensions", "normalization"}, "embedding accepted data")
            if data["endpoint"] != endpoint or not _int(data["total_items"]) or data["total_items"] < 1 or not _int(data["dimensions"]) or data["dimensions"] < 1 or data["normalization"] not in {"unit_l2", "none"} or any(not isinstance(data[key], str) for key in ("embedding_profile_id", "model", "requested_revision", "artifact_fingerprint")):
                raise ValueError("embedding accepted data is invalid")
        else:
            data = _exact(payload, {"endpoint", "scope_id", "message_count"}, "conversation accepted data")
            if data["endpoint"] != endpoint or not isinstance(data["scope_id"], str) or not _int(data["message_count"]) or data["message_count"] < 1:
                raise ValueError("conversation accepted data is invalid")
    elif event == "vector_batch":
        data = _exact(payload, {"batch_index", "items"}, "vector batch data")
        if not _int(data["batch_index"]) or data["batch_index"] < 0 or not isinstance(data["items"], list) or not data["items"]:
            raise ValueError("vector batch metadata is invalid")
        for item in data["items"]:
            item = _exact(item, {"message_id", "vector"}, "vector item")
            if not isinstance(item["message_id"], str) or not item["message_id"] or not isinstance(item["vector"], list) or not item["vector"] or any(not _number(number) or not math.isfinite(float(number)) for number in item["vector"]):
                raise ValueError("vector item is invalid")
    elif event == "completed":
        if endpoint == "/v1/embeddings":
            result = _exact(payload, {"total_items", "embedding_profile_id"}, "embedding completed result")
            if not _int(result["total_items"]) or result["total_items"] < 1 or not isinstance(result["embedding_profile_id"], str) or not result["embedding_profile_id"]:
                raise ValueError("embedding completed result is invalid")
        else:
            required = {"answer", "answer_summary", "strategy", "evidence_ledger", "uncertainties", "coverage", "usage"}
            result = _exact(payload, required, "conversation completed result")
            if not isinstance(result["answer"], str) or not result["answer"] or not isinstance(result["answer_summary"], str) or not result["answer_summary"] or result["strategy"] not in {"whole_corpus", "windowed_ledger"} or not isinstance(result["evidence_ledger"], list) or not isinstance(result["uncertainties"], list) or not isinstance(result["coverage"], dict) or not isinstance(result["usage"], dict):
                raise ValueError("conversation completed result is invalid")
            _exact(result["coverage"], {"message_count", "window_count", "evidence_range_count"}, "conversation coverage")
            usage = _exact(result["usage"], {"input_tokens", "output_tokens", "source", "estimated_cost", "cost_complete", "currency"}, "conversation usage")
            if usage["source"] not in {"provider_reported", "estimated", "mixed"} or not isinstance(usage["cost_complete"], bool) or usage["currency"] != "USD":
                raise ValueError("conversation usage is invalid")
            for record in result["evidence_ledger"]:
                record = _exact(record, {"range_id", "thread_id", "start_message_id", "end_message_id", "summary", "relevance", "disposition", "rationale"}, "evidence ledger record")
                if any(not isinstance(record[key], str) or not record[key] for key in ("range_id", "thread_id", "start_message_id", "end_message_id", "summary", "relevance", "rationale")) or record["disposition"] not in {"used", "redundant", "not_material"}:
                    raise ValueError("evidence ledger record is invalid")
    else:
        data_keys = {
            "queued": {"operation", "queued_count", "wait_timeout_ms"},
            "retry_wait": {"operation", "failed_attempt", "next_attempt", "delay_ms", "error_code"},
            "accounting_completed": {"corpus_tokens", "whole_input_tokens", "context_window_tokens", "reserved_output_tokens", "safety_margin_tokens", "strategy"},
            "whole_started": {"operation"},
            "retrieval_terms_started": {"operation"},
            "whole_completed": {"operation", "input_tokens", "output_tokens", "usage_source", "estimated_cost"},
            "retrieval_terms_completed": {"operation", "term_count", "input_tokens", "output_tokens", "usage_source", "estimated_cost"},
            "window_plan_created": {"window_count", "message_count", "target_input_tokens"},
            "window_started": {"window_id", "window_index", "window_count", "message_count"},
            "window_completed": {"window_id", "window_index", "window_count", "evidence_range_count", "input_tokens", "output_tokens", "usage_source", "estimated_cost"},
            "ledger_built": {"window_count", "evidence_range_count"},
            "ledger_reduction_started": {"level", "group_count", "covered_range_count"},
            "ledger_reduction_completed": {"level", "group_count", "covered_range_count", "input_tokens", "output_tokens", "usage_source", "estimated_cost"},
            "ledger_synthesis_started": {"evidence_range_count"},
            "ledger_synthesis_completed": {"evidence_range_count", "input_tokens", "output_tokens", "usage_source", "estimated_cost"},
            "embedding_batch_started": {"batch_index", "batch_count", "first_item_index", "last_item_index", "item_count"},
            "embedding_progress": {"completed_items", "total_items", "server_items_per_second"},
        }[event]
        data = _exact(payload, data_keys, f"{event} data")
        for key, item in data.items():
            if key in {"operation", "error_code", "window_id", "strategy", "usage_source"}:
                if not isinstance(item, str) or not item:
                    raise ValueError(f"{event}.{key} is invalid")
            elif key == "estimated_cost":
                if item is not None and (not _number(item) or float(item) < 0):
                    raise ValueError(f"{event}.estimated_cost is invalid")
            elif key == "server_items_per_second":
                if not _number(item) or float(item) < 0:
                    raise ValueError("embedding progress rate is invalid")
            elif not _int(item) or item < 0:
                raise ValueError(f"{event}.{key} is invalid")
    return value


@dataclass(frozen=True, slots=True)
class StreamEvent:
    value: dict[str, Any]

    @property
    def event(self) -> str:
        return str(self.value["event"])

    @property
    def terminal(self) -> bool:
        return self.event in {"completed", "failed"}
