"""Deterministic evidence-ledger construction and strict bijection validation."""

from __future__ import annotations

from dataclasses import dataclass
from types import MappingProxyType
from typing import Any, Callable, Iterable, Mapping, Sequence


class LedgerError(ValueError):
    code = "LEDGER_BIJECTION_FAILED"


class LedgerBudgetExceeded(LedgerError):
    code = "LEDGER_BUDGET_EXCEEDED"


class UnsplitableMessage(LedgerError):
    code = "UNSPLITTABLE_MESSAGE"


@dataclass(frozen=True, slots=True)
class EvidenceRangeRecord:
    range_id: str
    window_id: str
    thread_id: str
    start_message_id: str
    end_message_id: str
    messages: tuple[Mapping[str, Any], ...]
    summary: str
    relevance: str
    rationale: str | None
    uncertainties: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class WindowLedgerInput:
    window_id: str
    messages: tuple[Mapping[str, Any], ...]


@dataclass(frozen=True, slots=True)
class CoverageReport:
    window_id: str
    first_message_id: str
    last_message_id: str
    message_count: int
    evidence_range_count: int
    uncertainties: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class LedgerBuild:
    records: tuple[EvidenceRangeRecord, ...]
    coverage: tuple[CoverageReport, ...]


def _message_maps(messages: Sequence[Mapping[str, Any]]) -> tuple[dict[str, int], dict[str, str]]:
    by_id: dict[str, int] = {}
    by_thread: dict[str, str] = {}
    for index, message in enumerate(messages):
        message_id = str(message.get("message_id", ""))
        thread_id = str(message.get("thread_id", ""))
        if not message_id or not thread_id or message_id in by_id:
            raise LedgerError("window messages must have unique nonblank IDs")
        by_id[message_id] = index
        by_thread[message_id] = thread_id
    return by_id, by_thread


def _range_record(window: WindowLedgerInput, raw: Mapping[str, Any], range_id: str) -> EvidenceRangeRecord:
    by_id, by_thread = _message_maps(window.messages)
    try:
        start = str(raw["start_message_id"])
        end = str(raw["end_message_id"])
        thread_id = str(raw["thread_id"])
        summary = str(raw["summary"])
        relevance = str(raw["relevance"])
    except (KeyError, TypeError) as exc:
        raise LedgerError("evidence range is missing required fields") from exc
    if start not in by_id or end not in by_id or not thread_id.strip() or not summary.strip() or not relevance.strip():
        raise LedgerError("evidence range references an unknown or blank value")
    start_index, end_index = by_id[start], by_id[end]
    if start_index > end_index:
        raise LedgerError("evidence range is reversed")
    selected = window.messages[start_index : end_index + 1]
    if any(str(message.get("thread_id", "")) != thread_id for message in selected) or by_thread[start] != thread_id or by_thread[end] != thread_id:
        raise LedgerError("evidence range crosses a thread boundary")
    uncertainties = tuple(str(value) for value in raw.get("uncertainties", ()))
    rationale = raw.get("rationale")
    if rationale is not None and not isinstance(rationale, str):
        raise LedgerError("range rationale must be a string")
    return EvidenceRangeRecord(range_id, window.window_id, thread_id, start, end, tuple(MappingProxyType(dict(message)) for message in selected), summary, relevance, rationale, uncertainties)


def build_ledger(windows: Sequence[WindowLedgerInput], outputs: Sequence[Mapping[str, Any]]) -> LedgerBuild:
    if len(windows) != len(outputs):
        raise LedgerError("every window must produce exactly one output")
    records: list[EvidenceRangeRecord] = []
    coverage: list[CoverageReport] = []
    seen_windows: set[str] = set()
    for window, raw in zip(windows, outputs):
        if window.window_id in seen_windows:
            raise LedgerError("duplicate window ID")
        seen_windows.add(window.window_id)
        if str(raw.get("window_id", "")) != window.window_id:
            raise LedgerError("window output ID does not match request")
        _, _ = _message_maps(window.messages)
        raw_ranges = raw.get("evidence_ranges")
        if not isinstance(raw_ranges, list):
            raise LedgerError("evidence_ranges must be a list")
        if bool(raw.get("no_relevant_evidence")) and raw_ranges:
            raise LedgerError("no-relevant-evidence window cannot contain ranges")
        if not bool(raw.get("no_relevant_evidence")) and not raw_ranges:
            raise LedgerError("relevant-evidence window must contain a range")
        ids_in_window: set[tuple[str, str]] = set()
        for raw_range in raw_ranges:
            if not isinstance(raw_range, Mapping):
                raise LedgerError("range must be an object")
            pair = (str(raw_range.get("start_message_id", "")), str(raw_range.get("end_message_id", "")))
            if pair in ids_in_window:
                raise LedgerError("duplicate evidence range")
            ids_in_window.add(pair)
            records.append(_range_record(window, raw_range, f"r{len(records) + 1:06d}"))
        uncertainties = tuple(str(value) for value in raw.get("uncertainties", ()))
        coverage.append(CoverageReport(window.window_id, str(window.messages[0]["message_id"]), str(window.messages[-1]["message_id"]), len(window.messages), len(raw_ranges), uncertainties))
    return LedgerBuild(tuple(records), tuple(coverage))


def build_whole_ledger(messages: Sequence[Mapping[str, Any]], raw_ranges: Sequence[Mapping[str, Any]]) -> tuple[EvidenceRangeRecord, ...]:
    all_messages = tuple(messages)
    window = WindowLedgerInput("whole", all_messages)
    result: list[EvidenceRangeRecord] = []
    for raw in raw_ranges:
        if "rationale" not in raw or not str(raw.get("rationale", "")).strip():
            raise LedgerError("whole-path range rationale is required")
        result.append(_range_record(window, raw, f"r{len(result) + 1:06d}"))
    return tuple(result)


def validate_dispositions(range_ids: Sequence[str], dispositions: Sequence[Mapping[str, Any]]) -> dict[str, Mapping[str, Any]]:
    expected = list(range_ids)
    actual: dict[str, Mapping[str, Any]] = {}
    for item in dispositions:
        if not isinstance(item, Mapping):
            raise LedgerError("range disposition must be an object")
        range_id = str(item.get("range_id", ""))
        if range_id not in expected or range_id in actual:
            raise LedgerError("unknown or duplicate range disposition")
        if item.get("disposition") not in {"used", "redundant", "not_material"} or not str(item.get("rationale", "")).strip():
            raise LedgerError("invalid range disposition")
        actual[range_id] = MappingProxyType(dict(item))
    if list(actual) != expected:
        raise LedgerError("missing range disposition")
    return actual


def partition_records(records: Sequence[Any], fits: Callable[[Sequence[Any]], bool], *, level: int, max_depth: int = 4) -> tuple[tuple[str, tuple[Any, ...]], ...]:
    if level > max_depth:
        raise LedgerBudgetExceeded("ledger reduction depth exceeded")
    groups: list[tuple[str, tuple[Any, ...]]] = []
    current: list[Any] = []
    for record in records:
        candidate = tuple(current + [record])
        if not fits(candidate):
            if not current:
                raise LedgerBudgetExceeded("one ledger record cannot fit the configured budget")
            groups.append((f"g{level:02d}-{len(groups) + 1:06d}", tuple(current)))
            current = [record]
            if not fits(tuple(current)):
                raise LedgerBudgetExceeded("one ledger record cannot fit the configured budget")
        else:
            current.append(record)
    if current:
        groups.append((f"g{level:02d}-{len(groups) + 1:06d}", tuple(current)))
    return tuple(groups)


def assemble_final(*, answer: str, answer_summary: str, strategy: str, records: Sequence[EvidenceRangeRecord], dispositions: Sequence[Mapping[str, Any]], uncertainties: Sequence[str], message_count: int, window_count: int, usage: Mapping[str, Any]) -> dict[str, Any]:
    if not answer.strip() or not answer_summary.strip():
        raise LedgerError("final answer and summary must be nonblank")
    disposition_map = validate_dispositions([record.range_id for record in records], dispositions)
    ledger = [{"range_id": record.range_id, "thread_id": record.thread_id, "start_message_id": record.start_message_id, "end_message_id": record.end_message_id, "summary": record.summary, "relevance": record.relevance, "disposition": disposition_map[record.range_id]["disposition"], "rationale": disposition_map[record.range_id]["rationale"]} for record in records]
    return {"answer": answer, "answer_summary": answer_summary, "strategy": strategy, "evidence_ledger": ledger, "uncertainties": list(uncertainties), "coverage": {"message_count": message_count, "window_count": window_count, "evidence_range_count": len(records)}, "usage": dict(usage)}
