# Message Evidence Workstation — Server-First V1

The FastAPI server owns provider calls, prompts, model selection, accounting,
conversation orchestration, evidence-ledger synthesis, embedding batching,
retries, concurrency, usage accounting, and operational visibility. The
temporary Python client owns the local EVW, working-corpus scope, FTS5,
sqlite-vec, streamed progress, and local history.

## Start the server

```powershell
python -m server
```

Open [http://127.0.0.1:8710/admin/](http://127.0.0.1:8710/admin/) to complete
the loopback bootstrap configuration. Until a valid version is activated,
the three product routes return `CONFIGURATION_REQUIRED`.

Product routes:

- `POST /v1/keyword-expansion`
- `POST /v1/conversational-analysis`
- `POST /v1/embeddings`

FastAPI docs/OpenAPI and the old v2/capabilities/internal product routes are
disabled. The server stores only encrypted provider secrets, immutable
configuration/audit records, and append-only content-free usage records.

## Start the temporary Python EVW harness

```powershell
python -m message_evidence_workstation.app `
  --db C:\path\to\workspace.evw
```

Do not pass `--dataset` when opening an existing V14 EVW; that option imports
a normalized source dataset and builds a new working corpus.

The client submits one complete scoped conversation or embedding workload and
consumes the server's NDJSON stream. It never chooses provider models,
windows, retries, or server batch sizes.

Flutter server integration and further EVW schema changes are excluded from
this server-first phase; the existing read-only Flutter V14 viewer remains the
compatibility proof. Earlier transformation folders are historical evidence;
the authoritative execution packet is `docs/transformation/server_first_v1/`.

The exact visual acceptance sequence for the prepared V14 fixture is in
`docs/transformation/server_first_v1/manual_test.md`. Dependency installation,
automated tests, release builds, and native probes are executor work, not user
test steps.
