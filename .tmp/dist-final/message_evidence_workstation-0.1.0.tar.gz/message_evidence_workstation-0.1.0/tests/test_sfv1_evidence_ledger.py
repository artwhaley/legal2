import pytest

from server.evidence_ledger import LedgerBudgetExceeded, LedgerError, WindowLedgerInput, assemble_final, build_ledger, build_whole_ledger, partition_records


def messages():
    return ({"message_id": "m1", "thread_id": "t1", "timestamp": "1", "sender": "a", "text": "one"}, {"message_id": "m2", "thread_id": "t1", "timestamp": "2", "sender": "b", "text": "two"}, {"message_id": "m3", "thread_id": "t2", "timestamp": "3", "sender": "c", "text": "three"})


def test_ledger_ids_excerpts_and_coverage_are_deterministic():
    source = messages()
    build = build_ledger([WindowLedgerInput("w1", source[:2]), WindowLedgerInput("w2", source[2:])], [{"window_id": "w1", "no_relevant_evidence": False, "evidence_ranges": [{"thread_id": "t1", "start_message_id": "m1", "end_message_id": "m2", "summary": "s", "relevance": "r"}], "uncertainties": []}, {"window_id": "w2", "no_relevant_evidence": True, "evidence_ranges": [], "uncertainties": ["u"]}])
    assert [record.range_id for record in build.records] == ["r000001"]
    assert [message["message_id"] for message in build.records[0].messages] == ["m1", "m2"]
    assert build.coverage[1].message_count == 1


def test_invalid_ranges_and_whole_rationale_fail():
    source = messages()
    with pytest.raises(LedgerError):
        build_ledger([WindowLedgerInput("w1", source)], [{"window_id": "w1", "no_relevant_evidence": False, "evidence_ranges": [{"thread_id": "t1", "start_message_id": "m2", "end_message_id": "m3", "summary": "s", "relevance": "r"}], "uncertainties": []}])
    with pytest.raises(LedgerError):
        build_whole_ledger(source, [{"thread_id": "t1", "start_message_id": "m1", "end_message_id": "m2", "summary": "s", "relevance": "r"}])


def test_partition_and_final_bijection():
    groups = partition_records([1, 2, 3], lambda values: len(values) <= 2, level=1)
    assert [group[0] for group in groups] == ["g01-000001", "g01-000002"]
    source = messages()
    build = build_ledger([WindowLedgerInput("w1", source[:2])], [{"window_id": "w1", "no_relevant_evidence": False, "evidence_ranges": [{"thread_id": "t1", "start_message_id": "m1", "end_message_id": "m2", "summary": "s", "relevance": "r"}], "uncertainties": []}])
    final = assemble_final(answer="a", answer_summary="s", strategy="windowed_ledger", records=build.records, dispositions=[{"range_id": "r000001", "disposition": "used", "rationale": "supports"}], uncertainties=[], message_count=2, window_count=1, usage={"input_tokens": 1, "output_tokens": 1, "source": "estimated", "estimated_cost": None, "cost_complete": False, "currency": "USD"})
    assert final["evidence_ledger"][0]["range_id"] == "r000001"
    with pytest.raises(LedgerError):
        assemble_final(answer="a", answer_summary="s", strategy="windowed_ledger", records=build.records, dispositions=[], uncertainties=[], message_count=2, window_count=1, usage={})
    with pytest.raises(LedgerBudgetExceeded):
        partition_records([1], lambda values: False, level=1)
