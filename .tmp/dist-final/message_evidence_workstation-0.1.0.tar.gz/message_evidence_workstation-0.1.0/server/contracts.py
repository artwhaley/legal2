"""Versioned, strict product and internal model contracts."""

from __future__ import annotations

import math
import uuid
from datetime import datetime, timezone
from typing import Annotated, Any, Literal, Union

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)


def _nonblank(value: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError("must be a nonblank string")
    return value


class RequestModel(StrictModel):
    request_id: str

    @field_validator("request_id")
    @classmethod
    def valid_request_id(cls, value: str) -> str:
        _nonblank(value)
        try:
            uuid.UUID(value)
        except (ValueError, AttributeError) as exc:
            raise ValueError("request_id must be a UUID") from exc
        return value


class KeywordExpansionRequest(RequestModel):
    query: str

    @field_validator("query")
    @classmethod
    def question_nonblank(cls, value: str) -> str:
        return _nonblank(value)


class ConversationMessage(StrictModel):
    message_id: str
    thread_id: str
    timestamp: str
    sender: str
    text: str

    @field_validator("message_id", "thread_id")
    @classmethod
    def ids_nonblank(cls, value: str) -> str:
        return _nonblank(value)

    @field_validator("timestamp", "sender", "text")
    @classmethod
    def display_strings(cls, value: str) -> str:
        if not isinstance(value, str):
            raise ValueError("must be a string")
        return value


class WorkingCorpus(StrictModel):
    scope_id: str
    messages: list[ConversationMessage] = Field(min_length=1)

    @field_validator("scope_id")
    @classmethod
    def scope_nonblank(cls, value: str) -> str:
        return _nonblank(value)

    @model_validator(mode="after")
    def unique_ids(self) -> "WorkingCorpus":
        ids = [message.message_id for message in self.messages]
        threads = [message.thread_id for message in self.messages]
        if len(ids) != len(set(ids)) or len(threads) == 0:
            raise ValueError("message IDs must be unique and thread IDs present")
        return self


class ConversationalAnalysisRequest(RequestModel):
    question: str
    working_corpus: WorkingCorpus

    @field_validator("question")
    @classmethod
    def question_nonblank(cls, value: str) -> str:
        return _nonblank(value)


class EmbeddingItem(StrictModel):
    message_id: str
    text: str

    @field_validator("message_id")
    @classmethod
    def item_id_nonblank(cls, value: str) -> str:
        return _nonblank(value)


class EmbeddingsRequest(RequestModel):
    items: list[EmbeddingItem] = Field(min_length=1)

    @model_validator(mode="after")
    def unique_item_ids(self) -> "EmbeddingsRequest":
        ids = [item.message_id for item in self.items]
        if len(ids) != len(set(ids)):
            raise ValueError("embedding message IDs must be unique")
        return self


class UsageSummary(StrictModel):
    input_tokens: int = Field(ge=0)
    output_tokens: int = Field(ge=0)
    source: Literal["provider_reported", "mixed", "estimated"]
    estimated_cost: float | None = Field(default=None, ge=0)
    cost_complete: bool
    currency: Literal["USD"] = "USD"


class EvidenceRangeOutput(StrictModel):
    thread_id: str
    start_message_id: str
    end_message_id: str
    summary: str
    relevance: str
    rationale: str

    @field_validator("thread_id", "start_message_id", "end_message_id", "summary", "relevance", "rationale")
    @classmethod
    def range_strings(cls, value: str) -> str:
        return _nonblank(value)


class WholeCorpusOutput(StrictModel):
    answer: str
    answer_summary: str
    evidence_ranges: list[EvidenceRangeOutput]
    uncertainties: list[str]

    @field_validator("answer", "answer_summary")
    @classmethod
    def answer_strings(cls, value: str) -> str:
        return _nonblank(value)


class WindowEvidenceRangeOutput(StrictModel):
    thread_id: str
    start_message_id: str
    end_message_id: str
    summary: str
    relevance: str

    @field_validator("thread_id", "start_message_id", "end_message_id", "summary", "relevance")
    @classmethod
    def window_range_strings(cls, value: str) -> str:
        return _nonblank(value)


class WindowEvidenceOutput(StrictModel):
    window_id: str
    no_relevant_evidence: bool
    evidence_ranges: list[WindowEvidenceRangeOutput]
    uncertainties: list[str]

    @model_validator(mode="after")
    def empty_evidence_invariant(self) -> "WindowEvidenceOutput":
        if self.no_relevant_evidence != (len(self.evidence_ranges) == 0):
            raise ValueError("no_relevant_evidence must match evidence_ranges")
        if not self.window_id.strip():
            raise ValueError("window_id is required")
        return self


Disposition = Literal["used", "redundant", "not_material"]


class RangeDisposition(StrictModel):
    range_id: str
    disposition: Disposition
    rationale: str

    @field_validator("range_id", "rationale")
    @classmethod
    def disposition_strings(cls, value: str) -> str:
        return _nonblank(value)


class LedgerSynthesisOutput(StrictModel):
    answer: str
    answer_summary: str
    range_dispositions: list[RangeDisposition]
    uncertainties: list[str]

    @field_validator("answer", "answer_summary")
    @classmethod
    def synthesis_strings(cls, value: str) -> str:
        return _nonblank(value)


class LedgerReductionOutput(StrictModel):
    group_id: str
    summary: str
    covered_range_ids: list[str]
    range_dispositions: list[RangeDisposition]
    uncertainties: list[str]

    @field_validator("group_id", "summary")
    @classmethod
    def reduction_strings(cls, value: str) -> str:
        return _nonblank(value)


class KeywordExpansionOutput(StrictModel):
    terms: list[str] = Field(min_length=1, max_length=20)

    @field_validator("terms")
    @classmethod
    def valid_terms(cls, values: list[str]) -> list[str]:
        if any(not isinstance(value, str) or not value.strip() or value != value.strip() for value in values):
            raise ValueError("terms must be trimmed nonblank strings")
        if len(values) != len(set(values)):
            raise ValueError("terms must be unique")
        return values


class ConversationalEvidenceLedgerItem(StrictModel):
    range_id: str
    thread_id: str
    start_message_id: str
    end_message_id: str
    summary: str
    relevance: str
    disposition: Disposition
    rationale: str

    @field_validator("range_id", "thread_id", "start_message_id", "end_message_id", "summary", "relevance", "rationale")
    @classmethod
    def ledger_strings(cls, value: str) -> str:
        return _nonblank(value)


class Coverage(StrictModel):
    message_count: int = Field(ge=0)
    window_count: int = Field(ge=0)
    evidence_range_count: int = Field(ge=0)


class ConversationalResult(StrictModel):
    answer: str
    answer_summary: str
    strategy: Literal["whole_corpus", "windowed_ledger"]
    evidence_ledger: list[ConversationalEvidenceLedgerItem]
    uncertainties: list[str]
    coverage: Coverage
    usage: UsageSummary

    @field_validator("answer", "answer_summary")
    @classmethod
    def result_strings(cls, value: str) -> str:
        return _nonblank(value)


class KeywordExpansionResponse(StrictModel):
    request_id: str
    config_version: int = Field(ge=1)
    terms: list[str] = Field(min_length=1, max_length=20)
    usage: UsageSummary


class CommonError(StrictModel):
    request_id: str | None
    code: str
    message: str
    stage: Literal["request", "queue", "provider", "embedding", "whole", "window", "ledger", "synthesis"]
    retryable: bool
    details: dict[str, Any]


class ErrorResponse(StrictModel):
    request_id: str | None
    code: str
    message: str
    stage: str
    retryable: bool
    details: dict[str, Any]


class EventBase(StrictModel):
    request_id: str
    sequence: int = Field(ge=1)
    event: str
    timestamp: str
    config_version: int = Field(ge=1)

    @field_validator("timestamp")
    @classmethod
    def utc_timestamp(cls, value: str) -> str:
        try:
            parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError as exc:
            raise ValueError("timestamp must be RFC 3339") from exc
        if parsed.tzinfo is None:
            raise ValueError("timestamp must include timezone")
        return value


class AcceptedConversationData(StrictModel):
    endpoint: Literal["/v1/conversational-analysis"]
    scope_id: str
    message_count: int = Field(ge=1)


class AcceptedEmbeddingsData(StrictModel):
    endpoint: Literal["/v1/embeddings"]
    total_items: int = Field(ge=1)
    embedding_profile_id: str
    model: str
    requested_revision: str
    artifact_fingerprint: str
    dimensions: int = Field(gt=0)
    normalization: Literal["unit_l2", "none"]


class AcceptedConversationEvent(EventBase):
    event: Literal["accepted"]
    data: AcceptedConversationData


class AcceptedEmbeddingsEvent(EventBase):
    event: Literal["accepted"]
    data: AcceptedEmbeddingsData


class QueuedData(StrictModel):
    operation: str
    queued_count: int = Field(ge=0)
    wait_timeout_ms: int = Field(ge=0)


class RetryWaitData(StrictModel):
    operation: str
    failed_attempt: int = Field(ge=1)
    next_attempt: int = Field(ge=1)
    delay_ms: int = Field(ge=0)
    error_code: str


class AccountingData(StrictModel):
    corpus_tokens: int = Field(ge=0)
    whole_input_tokens: int = Field(ge=0)
    context_window_tokens: int = Field(gt=0)
    reserved_output_tokens: int = Field(ge=0)
    safety_margin_tokens: int = Field(ge=0)
    strategy: Literal["whole_corpus", "windowed_ledger"]


class OperationData(StrictModel):
    operation: str


class UsageEventData(StrictModel):
    operation: str
    term_count: int | None = Field(default=None, ge=0)
    evidence_range_count: int | None = Field(default=None, ge=0)
    input_tokens: int = Field(ge=0)
    output_tokens: int = Field(ge=0)
    usage_source: Literal["provider_reported", "estimated"]
    estimated_cost: float | None = Field(default=None, ge=0)


class WholeCompletedData(StrictModel):
    operation: str
    input_tokens: int = Field(ge=0)
    output_tokens: int = Field(ge=0)
    usage_source: Literal["provider_reported", "estimated"]
    estimated_cost: float | None = Field(ge=0)


class RetrievalCompletedData(WholeCompletedData):
    term_count: int = Field(ge=0)


class WindowCompletedData(StrictModel):
    window_id: str
    window_index: int = Field(ge=0)
    window_count: int = Field(gt=0)
    evidence_range_count: int = Field(ge=0)
    input_tokens: int = Field(ge=0)
    output_tokens: int = Field(ge=0)
    usage_source: Literal["provider_reported", "estimated"]
    estimated_cost: float | None = Field(ge=0)


class ReductionCompletedData(StrictModel):
    level: int = Field(ge=1)
    group_count: int = Field(ge=1)
    covered_range_count: int = Field(ge=0)
    input_tokens: int = Field(ge=0)
    output_tokens: int = Field(ge=0)
    usage_source: Literal["provider_reported", "estimated"]
    estimated_cost: float | None = Field(ge=0)


class SynthesisCompletedData(StrictModel):
    evidence_range_count: int = Field(ge=0)
    input_tokens: int = Field(ge=0)
    output_tokens: int = Field(ge=0)
    usage_source: Literal["provider_reported", "estimated"]
    estimated_cost: float | None = Field(ge=0)


class WindowPlanData(StrictModel):
    window_count: int = Field(ge=1)
    message_count: int = Field(ge=1)
    target_input_tokens: int = Field(gt=0)


class WindowStartedData(StrictModel):
    window_id: str
    window_index: int = Field(ge=0)
    window_count: int = Field(gt=0)
    message_count: int = Field(ge=1)


class LedgerReductionData(StrictModel):
    level: int = Field(ge=1)
    group_count: int = Field(ge=1)
    covered_range_count: int = Field(ge=0)


class EmbeddingBatchStartedData(StrictModel):
    batch_index: int = Field(ge=0)
    batch_count: int = Field(gt=0)
    first_item_index: int = Field(ge=0)
    last_item_index: int = Field(ge=0)
    item_count: int = Field(gt=0)

    @model_validator(mode="after")
    def bounds(self) -> "EmbeddingBatchStartedData":
        if self.last_item_index < self.first_item_index or self.item_count != self.last_item_index - self.first_item_index + 1:
            raise ValueError("embedding batch bounds are inconsistent")
        return self


class VectorItem(StrictModel):
    message_id: str
    vector: list[float]

    @field_validator("vector")
    @classmethod
    def finite_vector(cls, values: list[float]) -> list[float]:
        if not values or any(not math.isfinite(value) for value in values):
            raise ValueError("vector must contain finite floats")
        return values


class VectorBatchData(StrictModel):
    batch_index: int = Field(ge=0)
    items: list[VectorItem] = Field(min_length=1)


class EmbeddingProgressData(StrictModel):
    completed_items: int = Field(ge=0)
    total_items: int = Field(gt=0)
    server_items_per_second: float = Field(ge=0)


class QueuedEvent(EventBase):
    event: Literal["queued"]
    data: QueuedData


class RetryWaitEvent(EventBase):
    event: Literal["retry_wait"]
    data: RetryWaitData


class AccountingEvent(EventBase):
    event: Literal["accounting_completed"]
    data: AccountingData


class OperationEvent(EventBase):
    event: Literal["whole_started", "retrieval_terms_started"]
    data: OperationData


class WholeCompletedEvent(EventBase):
    event: Literal["whole_completed"]
    data: WholeCompletedData


class RetrievalCompletedEvent(EventBase):
    event: Literal["retrieval_terms_completed"]
    data: RetrievalCompletedData


class WindowCompletedEvent(EventBase):
    event: Literal["window_completed"]
    data: WindowCompletedData


class ReductionCompletedEvent(EventBase):
    event: Literal["ledger_reduction_completed"]
    data: ReductionCompletedData


class SynthesisCompletedEvent(EventBase):
    event: Literal["ledger_synthesis_completed"]
    data: SynthesisCompletedData


class WindowPlanEvent(EventBase):
    event: Literal["window_plan_created"]
    data: WindowPlanData


class WindowStartedEvent(EventBase):
    event: Literal["window_started"]
    data: WindowStartedData


class LedgerBuiltData(StrictModel):
    window_count: int = Field(ge=1)
    evidence_range_count: int = Field(ge=0)


class LedgerBuiltEvent(EventBase):
    event: Literal["ledger_built"]
    data: LedgerBuiltData


class LedgerReductionStartedEvent(EventBase):
    event: Literal["ledger_reduction_started"]
    data: LedgerReductionData


class LedgerSynthesisStartedData(StrictModel):
    evidence_range_count: int = Field(ge=0)


class LedgerSynthesisStartedEvent(EventBase):
    event: Literal["ledger_synthesis_started"]
    data: LedgerSynthesisStartedData


class EmbeddingBatchStartedEvent(EventBase):
    event: Literal["embedding_batch_started"]
    data: EmbeddingBatchStartedData


class VectorBatchEvent(EventBase):
    event: Literal["vector_batch"]
    data: VectorBatchData


class EmbeddingProgressEvent(EventBase):
    event: Literal["embedding_progress"]
    data: EmbeddingProgressData


class FailedEvent(EventBase):
    event: Literal["failed"]
    error: CommonError


class CompletedConversationEvent(EventBase):
    event: Literal["completed"]
    result: ConversationalResult


class CompletedEmbeddingsResult(StrictModel):
    total_items: int = Field(ge=1)
    embedding_profile_id: str


class CompletedEmbeddingsEvent(EventBase):
    event: Literal["completed"]
    result: CompletedEmbeddingsResult


NDJSONEvent = Union[AcceptedConversationEvent, AcceptedEmbeddingsEvent, QueuedEvent, RetryWaitEvent, AccountingEvent, OperationEvent, WholeCompletedEvent, RetrievalCompletedEvent, WindowPlanEvent, WindowStartedEvent, WindowCompletedEvent, LedgerBuiltEvent, LedgerReductionStartedEvent, ReductionCompletedEvent, LedgerSynthesisStartedEvent, SynthesisCompletedEvent, EmbeddingBatchStartedEvent, VectorBatchEvent, EmbeddingProgressEvent, FailedEvent, CompletedConversationEvent, CompletedEmbeddingsEvent]


def parse_ndjson_event(value: dict[str, Any], *, endpoint: str) -> NDJSONEvent:
    """Parse one strict stream event and reject endpoint-incompatible shapes."""
    from pydantic import TypeAdapter
    event_name = value.get("event")
    if endpoint not in {"/v1/conversational-analysis", "/v1/embeddings"}:
        raise ValueError(f"unknown stream endpoint {endpoint!r}")
    conversation_events = {
        "accepted", "queued", "retry_wait", "accounting_completed",
        "whole_started", "whole_completed", "retrieval_terms_started",
        "retrieval_terms_completed", "window_plan_created", "window_started",
        "window_completed", "ledger_built", "ledger_reduction_started",
        "ledger_reduction_completed", "ledger_synthesis_started",
        "ledger_synthesis_completed", "failed", "completed",
    }
    embedding_events = {
        "accepted", "queued", "embedding_batch_started", "vector_batch",
        "embedding_progress", "failed", "completed",
    }
    allowed_events = conversation_events if endpoint == "/v1/conversational-analysis" else embedding_events
    if event_name not in allowed_events:
        raise ValueError(f"event {event_name!r} is not valid for {endpoint}")
    event_model = {
        "accepted": AcceptedConversationEvent if endpoint == "/v1/conversational-analysis" else AcceptedEmbeddingsEvent,
        "failed": FailedEvent,
        "completed": CompletedConversationEvent if endpoint == "/v1/conversational-analysis" else CompletedEmbeddingsEvent,
        "queued": QueuedEvent,
        "retry_wait": RetryWaitEvent,
        "accounting_completed": AccountingEvent,
        "whole_started": OperationEvent,
        "retrieval_terms_started": OperationEvent,
        "whole_completed": WholeCompletedEvent,
        "retrieval_terms_completed": RetrievalCompletedEvent,
        "window_plan_created": WindowPlanEvent,
        "window_started": WindowStartedEvent,
        "window_completed": WindowCompletedEvent,
        "ledger_built": LedgerBuiltEvent,
        "ledger_reduction_started": LedgerReductionStartedEvent,
        "ledger_reduction_completed": ReductionCompletedEvent,
        "ledger_synthesis_started": LedgerSynthesisStartedEvent,
        "ledger_synthesis_completed": SynthesisCompletedEvent,
        "embedding_batch_started": EmbeddingBatchStartedEvent,
        "vector_batch": VectorBatchEvent,
        "embedding_progress": EmbeddingProgressEvent,
    }.get(event_name)
    if event_model is None:
        raise ValueError(f"unknown stream event {event_name!r}")
    event = TypeAdapter(event_model).validate_python(value)
    return event


SCHEMA_REGISTRY: dict[str, dict[str, Any]] = {
    "keyword_expansion": {"request": KeywordExpansionRequest.model_json_schema(), "response": KeywordExpansionResponse.model_json_schema(), "model_output": KeywordExpansionOutput.model_json_schema()},
    "conversational_analysis": {"request": ConversationalAnalysisRequest.model_json_schema(), "response": ConversationalResult.model_json_schema(), "model_output": WholeCorpusOutput.model_json_schema()},
    "embeddings": {"request": EmbeddingsRequest.model_json_schema(), "response": CompletedEmbeddingsResult.model_json_schema()},
    "window_evidence_extraction": {"model_output": WindowEvidenceOutput.model_json_schema()},
    "ledger_reduction": {"model_output": LedgerReductionOutput.model_json_schema()},
    "ledger_synthesis": {"model_output": LedgerSynthesisOutput.model_json_schema()},
}
SCHEMA_REGISTRY["retrieval_terms"] = {
    "model_output": KeywordExpansionOutput.model_json_schema()
}
SCHEMA_REGISTRY["whole_corpus_answer"] = {
    "model_output": WholeCorpusOutput.model_json_schema()
}
