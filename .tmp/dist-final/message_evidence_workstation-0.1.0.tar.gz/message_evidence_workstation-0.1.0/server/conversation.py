"""Server-owned whole-corpus or exhaustive windowed conversational analysis."""

from __future__ import annotations

import asyncio
import json
from datetime import datetime, timezone
from typing import Any, Mapping, Sequence

from fastapi.responses import StreamingResponse

from server.config import OperationConfig
from server.contracts import (
    ConversationalAnalysisRequest,
    KeywordExpansionOutput,
    LedgerReductionOutput,
    LedgerSynthesisOutput,
    SCHEMA_REGISTRY,
    WindowEvidenceOutput,
    WholeCorpusOutput,
    parse_ndjson_event,
)
from server.evidence_ledger import (
    EvidenceRangeRecord,
    LedgerBudgetExceeded,
    LedgerError,
    WindowLedgerInput,
    assemble_final,
    build_ledger,
    build_whole_ledger,
    partition_records,
    validate_dispositions,
)
from server.model_runtime import (
    UsageCollector,
    UsageEntry,
    WorkloadTooLarge,
    run_model_operation,
)
from server.observability import map_error
from server.token_accounting import (
    build_provider_payload,
    canonical_json,
    count_provider_payload,
)


class ModelInvocation:
    """Expose retry/queue progress while one strict model task is running."""

    def __init__(self, task: asyncio.Task[Any], queue: asyncio.Queue[tuple[str, dict[str, Any]]]):
        self.task = task
        self.queue = queue

    async def progress(self):
        while not self.task.done() or not self.queue.empty():
            if not self.queue.empty():
                yield self.queue.get_nowait()
                continue
            progress_task = asyncio.create_task(self.queue.get())
            done, _ = await asyncio.wait({self.task, progress_task}, return_when=asyncio.FIRST_COMPLETED)
            if progress_task in done:
                yield progress_task.result()
            else:
                progress_task.cancel()
                await asyncio.gather(progress_task, return_exceptions=True)

    def result(self):
        return self.task.result()


class UnsplittableMessage(ValueError):
    code = "UNSPLITTABLE_MESSAGE"


class Sequencer:
    def __init__(self, request_id: str, config_version: int, endpoint: str):
        self.request_id = request_id
        self.config_version = config_version
        self.endpoint = endpoint
        self.sequence = 0

    def event(
        self,
        name: str,
        *,
        data: dict[str, Any] | None = None,
        result: dict[str, Any] | None = None,
        error: dict[str, Any] | None = None,
    ) -> str:
        self.sequence += 1
        envelope: dict[str, Any] = {
            "request_id": self.request_id,
            "sequence": self.sequence,
            "event": name,
            "timestamp": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "config_version": self.config_version,
        }
        if name == "failed":
            envelope["error"] = error
        elif name == "completed":
            envelope["result"] = result
        else:
            envelope["data"] = data or {}
        parse_ndjson_event(envelope, endpoint=self.endpoint)
        return json.dumps(envelope, ensure_ascii=False, separators=(",", ":")) + "\n"


def _message_dict(message: Any) -> dict[str, str]:
    return {
        "message_id": message.message_id,
        "thread_id": message.thread_id,
        "timestamp": message.timestamp,
        "sender": message.sender,
        "text": message.text,
    }


def _user(task: str, **fields: Any) -> dict[str, Any]:
    return {"task": task, **fields}


def _input_target(operation: OperationConfig, configured_target: int | None = None) -> int:
    hard = operation.context_window_tokens - operation.max_output_tokens - operation.safety_margin_tokens
    candidates = [hard]
    if operation.target_input_tokens is not None:
        candidates.append(operation.target_input_tokens)
    if configured_target is not None:
        candidates.append(configured_target)
    return min(candidates)


def _payload_fits(
    operation_name: str,
    operation: OperationConfig,
    user_object: dict[str, Any],
    schema: dict[str, Any],
    *,
    target: int | None = None,
) -> bool:
    wire = [
        {"role": "system", "content": operation.system_prompt},
        {"role": "user", "content": canonical_json(user_object)},
    ]
    payload = build_provider_payload(
        operation,
        operation=operation_name,
        messages=wire,
        user_object=user_object,
        response_schema=schema,
    )
    accounting = count_provider_payload(payload, operation)
    return accounting.fits and accounting.input_tokens <= _input_target(operation, target)


def plan_windows(
    messages: Sequence[Mapping[str, Any]],
    *,
    question: str,
    retrieval_terms: list[str],
    operation: OperationConfig,
    configured_target: int,
) -> list[WindowLedgerInput]:
    """Pack each message exactly once, splitting threads only between messages."""
    target = _input_target(operation, configured_target)
    if target <= 0:
        raise UnsplittableMessage("window input budget is not positive")
    windows: list[WindowLedgerInput] = []
    current: list[Mapping[str, Any]] = []
    current_thread: str | None = None

    def fits(candidate: Sequence[Mapping[str, Any]], window_id: str) -> bool:
        return _payload_fits(
            "window_evidence_extraction",
            operation,
            _user(
                "window_evidence_extraction",
                question=question,
                retrieval_terms=retrieval_terms,
                window_id=window_id,
                messages=list(candidate),
            ),
            SCHEMA_REGISTRY["window_evidence_extraction"]["model_output"],
            target=target,
        )

    def append_current() -> None:
        if current:
            windows.append(
                WindowLedgerInput(f"w{len(windows) + 1:06d}", tuple(current))
            )

    for message in messages:
        thread_id = str(message["thread_id"])
        window_id = f"w{len(windows) + 1:06d}"
        if not current:
            if not fits([message], window_id):
                raise UnsplittableMessage(
                    f"message {message['message_id']} cannot fit a configured window"
                )
            current = [message]
            current_thread = thread_id
            continue
        if thread_id == current_thread and fits(current + [message], window_id):
            current.append(message)
            continue
        append_current()
        current = []
        current_thread = None
        window_id = f"w{len(windows) + 1:06d}"
        if not fits([message], window_id):
            raise UnsplittableMessage(
                f"message {message['message_id']} cannot fit a configured window"
            )
        current = [message]
        current_thread = thread_id
    append_current()

    flattened = [str(item["message_id"]) for window in windows for item in window.messages]
    expected = [str(item["message_id"]) for item in messages]
    if flattened != expected:
        raise RuntimeError("window planner changed message identity or order")
    return windows


def _record_payload(record: EvidenceRangeRecord) -> dict[str, Any]:
    return {
        "range_id": record.range_id,
        "window_id": record.window_id,
        "thread_id": record.thread_id,
        "start_message_id": record.start_message_id,
        "end_message_id": record.end_message_id,
        "summary": record.summary,
        "relevance": record.relevance,
        "messages": [dict(message) for message in record.messages],
        "uncertainties": list(record.uncertainties),
    }


def _original_range_ids(items: Sequence[Mapping[str, Any]]) -> list[str]:
    result: list[str] = []
    for item in items:
        if "range_id" in item:
            ids = [str(item["range_id"])]
        else:
            raw_ids = item.get("covered_range_ids")
            if not isinstance(raw_ids, list):
                raise LedgerError("reduction input has no original range coverage")
            ids = [str(value) for value in raw_ids]
        if any(not value or value in result for value in ids):
            raise LedgerError("reduction input has duplicate or blank range coverage")
        result.extend(ids)
    return result


async def run_conversational_stream(app, raw_body: dict[str, Any]) -> StreamingResponse:
    snapshot = app.state.config_service.snapshot()
    request = ConversationalAnalysisRequest.model_validate(raw_body)
    raw_size = len(json.dumps(raw_body, ensure_ascii=False, separators=(",", ":")).encode("utf-8"))
    if raw_size > snapshot.global_config.maximum_product_request_bytes:
        raise WorkloadTooLarge("conversational request body exceeds configured ceiling")

    endpoint = "/v1/conversational-analysis"
    whole_operation = snapshot.operations["whole_corpus_answer"]
    window_operation = snapshot.operations["window_evidence_extraction"]
    messages = [_message_dict(message) for message in request.working_corpus.messages]
    whole_user = _user(
        "whole_corpus_answer",
        question=request.question,
        scope_id=request.working_corpus.scope_id,
        messages=messages,
    )
    whole_wire = [
        {"role": "system", "content": whole_operation.system_prompt},
        {"role": "user", "content": canonical_json(whole_user)},
    ]
    whole_payload = build_provider_payload(
        whole_operation,
        operation="whole_corpus_answer",
        messages=whole_wire,
        user_object=whole_user,
        response_schema=SCHEMA_REGISTRY["whole_corpus_answer"]["model_output"],
    )
    whole_accounting = count_provider_payload(whole_payload, whole_operation)
    if whole_accounting.input_tokens > snapshot.global_config.maximum_conversational_corpus_tokens:
        raise WorkloadTooLarge("working corpus exceeds configured conversational ceiling")
    strategy = "whole_corpus" if whole_accounting.fits else "windowed_ledger"
    sequencer = Sequencer(request.request_id, snapshot.config_version, endpoint)
    collector = UsageCollector()

    def model_call(operation: str, user_object: dict[str, Any], output_model) -> ModelInvocation:
        progress_queue: asyncio.Queue[tuple[str, dict[str, Any]]] = asyncio.Queue()
        task = asyncio.create_task(run_model_operation(
            app,
            snapshot=snapshot,
            request_id=request.request_id,
            product_endpoint=endpoint,
            operation_name=operation,
            user_object=user_object,
            response_schema=SCHEMA_REGISTRY[operation]["model_output"],
            output_model=output_model,
            collector=collector,
            progress_queue=progress_queue,
        ))
        return ModelInvocation(task, progress_queue)

    async def stream():
        active_tasks: set[asyncio.Task[Any]] = set()

        def logged(name: str, **fields: Any) -> None:
            app.state.events.emit(
                name,
                request_id=request.request_id,
                config_version=snapshot.config_version,
                product_endpoint=endpoint,
                strategy=strategy,
                **fields,
            )

        try:
            logged("request_accepted")
            yield sequencer.event(
                "accepted",
                data={
                    "endpoint": endpoint,
                    "scope_id": request.working_corpus.scope_id,
                    "message_count": len(messages),
                },
            )
            yield sequencer.event(
                "accounting_completed",
                data={
                    "corpus_tokens": whole_accounting.input_tokens,
                    "whole_input_tokens": whole_accounting.input_tokens,
                    "context_window_tokens": whole_operation.context_window_tokens,
                    "reserved_output_tokens": whole_operation.max_output_tokens,
                    "safety_margin_tokens": whole_operation.safety_margin_tokens,
                    "strategy": strategy,
                },
            )

            if strategy == "whole_corpus":
                yield sequencer.event("whole_started", data={"operation": "whole_corpus_answer"})
                invocation = model_call("whole_corpus_answer", whole_user, WholeCorpusOutput)
                async for progress_name, progress_data in invocation.progress():
                    yield sequencer.event(progress_name, data=progress_data)
                output, usage = invocation.result()
                records = build_whole_ledger(messages, [item.model_dump() for item in output.evidence_ranges])
                dispositions = [
                    {"range_id": record.range_id, "disposition": "used", "rationale": record.rationale}
                    for record in records
                ]
                result = assemble_final(
                    answer=output.answer,
                    answer_summary=output.answer_summary,
                    strategy="whole_corpus",
                    records=records,
                    dispositions=dispositions,
                    uncertainties=output.uncertainties,
                    message_count=len(messages),
                    window_count=1,
                    usage=collector.summary(),
                )
                yield sequencer.event(
                    "whole_completed",
                    data={
                        "operation": "whole_corpus_answer",
                        "input_tokens": usage.input_tokens,
                        "output_tokens": usage.output_tokens,
                        "usage_source": usage.source,
                        "estimated_cost": usage.cost,
                    },
                )
                logged("request_completed")
                yield sequencer.event("completed", result=result)
                return

            retrieval_terms: list[str] = []
            if snapshot.global_config.retrieval_assistance_enabled:
                yield sequencer.event("retrieval_terms_started", data={"operation": "retrieval_terms"})
                invocation = model_call(
                    "retrieval_terms",
                    _user("retrieval_terms", question=request.question),
                    KeywordExpansionOutput,
                )
                async for progress_name, progress_data in invocation.progress():
                    yield sequencer.event(progress_name, data=progress_data)
                retrieval, usage = invocation.result()
                retrieval_terms = list(dict.fromkeys(term.strip() for term in retrieval.terms))
                yield sequencer.event(
                    "retrieval_terms_completed",
                    data={
                        "operation": "retrieval_terms",
                        "term_count": len(retrieval_terms),
                        "input_tokens": usage.input_tokens,
                        "output_tokens": usage.output_tokens,
                        "usage_source": usage.source,
                        "estimated_cost": usage.cost,
                    },
                )

            windows = plan_windows(
                messages,
                question=request.question,
                retrieval_terms=retrieval_terms,
                operation=window_operation,
                configured_target=snapshot.global_config.window_target_input_tokens,
            )
            target = _input_target(window_operation, snapshot.global_config.window_target_input_tokens)
            yield sequencer.event(
                "window_plan_created",
                data={"window_count": len(windows), "message_count": len(messages), "target_input_tokens": target},
            )
            outputs: list[dict[str, Any] | None] = [None] * len(windows)

            async def run_window(index: int, window: WindowLedgerInput, progress_queue):
                output, usage = await run_model_operation(
                    app,
                    snapshot=snapshot,
                    request_id=request.request_id,
                    product_endpoint=endpoint,
                    operation_name="window_evidence_extraction",
                    user_object=_user(
                        "window_evidence_extraction",
                        question=request.question,
                        retrieval_terms=retrieval_terms,
                        window_id=window.window_id,
                        messages=list(window.messages),
                    ),
                    response_schema=SCHEMA_REGISTRY["window_evidence_extraction"]["model_output"],
                    output_model=WindowEvidenceOutput,
                    collector=collector,
                    progress_queue=progress_queue,
                )
                if output.window_id != window.window_id:
                    raise LedgerError("window output ID does not match its request")
                return index, output, usage

            maximum = snapshot.global_config.maximum_concurrent_windows
            for start in range(0, len(windows), maximum):
                batch = windows[start : start + maximum]
                batch_progress: asyncio.Queue[tuple[str, dict[str, Any]]] = asyncio.Queue()
                for offset, window in enumerate(batch):
                    index = start + offset
                    logged("window_started", internal_operation="window_evidence_extraction")
                    yield sequencer.event(
                        "window_started",
                        data={
                            "window_id": window.window_id,
                            "window_index": index,
                            "window_count": len(windows),
                            "message_count": len(window.messages),
                        },
                    )
                    active_tasks.add(asyncio.create_task(run_window(index, window, batch_progress)))
                try:
                    while active_tasks:
                        progress_task = asyncio.create_task(batch_progress.get())
                        done, _ = await asyncio.wait(active_tasks | {progress_task}, return_when=asyncio.FIRST_COMPLETED)
                        if progress_task in done:
                            progress_name, progress_data = progress_task.result()
                            yield sequencer.event(progress_name, data=progress_data)
                        else:
                            progress_task.cancel()
                            await asyncio.gather(progress_task, return_exceptions=True)
                        finished = [task for task in done if task in active_tasks]
                        for finished_task in finished:
                            active_tasks.remove(finished_task)
                            index, output, usage = finished_task.result()
                            outputs[index] = output.model_dump()
                            logged("window_completed", internal_operation="window_evidence_extraction")
                            yield sequencer.event(
                                "window_completed",
                                data={
                                    "window_id": windows[index].window_id,
                                    "window_index": index,
                                    "window_count": len(windows),
                                    "evidence_range_count": len(output.evidence_ranges),
                                    "input_tokens": usage.input_tokens,
                                    "output_tokens": usage.output_tokens,
                                    "usage_source": usage.source,
                                    "estimated_cost": usage.cost,
                                },
                            )
                    while not batch_progress.empty():
                        progress_name, progress_data = batch_progress.get_nowait()
                        yield sequencer.event(progress_name, data=progress_data)
                except BaseException:
                    for task in active_tasks:
                        task.cancel()
                    await asyncio.gather(*active_tasks, return_exceptions=True)
                    active_tasks.clear()
                    raise

            if any(output is None for output in outputs):
                raise LedgerError("a required window output is missing")
            ledger = build_ledger(windows, [output for output in outputs if output is not None])
            yield sequencer.event(
                "ledger_built",
                data={"window_count": len(windows), "evidence_range_count": len(ledger.records)},
            )
            metadata = [
                {
                    "range_id": record.range_id,
                    "thread_id": record.thread_id,
                    "start_message_id": record.start_message_id,
                    "end_message_id": record.end_message_id,
                    "summary": record.summary,
                    "relevance": record.relevance,
                }
                for record in ledger.records
            ]
            coverage = [
                {
                    "window_id": item.window_id,
                    "first_message_id": item.first_message_id,
                    "last_message_id": item.last_message_id,
                    "message_count": item.message_count,
                    "evidence_range_count": item.evidence_range_count,
                    "uncertainties": list(item.uncertainties),
                }
                for item in ledger.coverage
            ]
            highest: list[dict[str, Any]] = [_record_payload(record) for record in ledger.records]
            synthesis_operation = snapshot.operations["ledger_synthesis"]

            def synthesis_user() -> dict[str, Any]:
                return _user(
                    "ledger_synthesis",
                    question=request.question,
                    coverage_report=coverage,
                    ledger_metadata=metadata,
                    records_or_highest_level_summaries=highest,
                )

            for level in range(0, snapshot.global_config.ledger_reduction_max_depth + 1):
                if _payload_fits(
                    "ledger_synthesis",
                    synthesis_operation,
                    synthesis_user(),
                    SCHEMA_REGISTRY["ledger_synthesis"]["model_output"],
                ):
                    break
                if not highest or level >= snapshot.global_config.ledger_reduction_max_depth:
                    raise LedgerBudgetExceeded("evidence ledger cannot fit configured synthesis budget")
                reduction_level = level + 1
                reduction_operation = snapshot.operations["ledger_reduction"]

                def group_fits(candidate: Sequence[Mapping[str, Any]]) -> bool:
                    return _payload_fits(
                        "ledger_reduction",
                        reduction_operation,
                        _user(
                            "ledger_reduction",
                            question=request.question,
                            level=reduction_level,
                            group_id=f"g{reduction_level:02d}-probe",
                            coverage_report=coverage,
                            records_or_summaries=list(candidate),
                        ),
                        SCHEMA_REGISTRY["ledger_reduction"]["model_output"],
                    )

                groups = partition_records(
                    highest,
                    group_fits,
                    level=reduction_level,
                    max_depth=snapshot.global_config.ledger_reduction_max_depth,
                )
                reduced: list[dict[str, Any]] = []
                for group_id, group in groups:
                    expected_ids = _original_range_ids(group)
                    yield sequencer.event(
                        "ledger_reduction_started",
                        data={
                            "level": reduction_level,
                            "group_count": len(groups),
                            "covered_range_count": len(expected_ids),
                        },
                    )
                    invocation = model_call(
                        "ledger_reduction",
                        _user(
                            "ledger_reduction",
                            question=request.question,
                            level=reduction_level,
                            group_id=group_id,
                            coverage_report=coverage,
                            records_or_summaries=list(group),
                        ),
                        LedgerReductionOutput,
                    )
                    async for progress_name, progress_data in invocation.progress():
                        yield sequencer.event(progress_name, data=progress_data)
                    reduction, usage = invocation.result()
                    if reduction.group_id != group_id or reduction.covered_range_ids != expected_ids:
                        raise LedgerError("reduction group did not preserve original range coverage")
                    validate_dispositions(expected_ids, [item.model_dump() for item in reduction.range_dispositions])
                    reduced.append({"level": reduction_level, **reduction.model_dump()})
                    yield sequencer.event(
                        "ledger_reduction_completed",
                        data={
                            "level": reduction_level,
                            "group_count": len(groups),
                            "covered_range_count": len(expected_ids),
                            "input_tokens": usage.input_tokens,
                            "output_tokens": usage.output_tokens,
                            "usage_source": usage.source,
                            "estimated_cost": usage.cost,
                        },
                    )
                if _original_range_ids(reduced) != [record.range_id for record in ledger.records]:
                    raise LedgerError("reduction level changed global range coverage or order")
                highest = reduced
            else:  # pragma: no cover - loop always exits through break or explicit error
                raise LedgerBudgetExceeded("evidence ledger reduction did not converge")

            yield sequencer.event(
                "ledger_synthesis_started",
                data={"evidence_range_count": len(ledger.records)},
            )
            invocation = model_call("ledger_synthesis", synthesis_user(), LedgerSynthesisOutput)
            async for progress_name, progress_data in invocation.progress():
                yield sequencer.event(progress_name, data=progress_data)
            final, usage = invocation.result()
            result = assemble_final(
                answer=final.answer,
                answer_summary=final.answer_summary,
                strategy="windowed_ledger",
                records=ledger.records,
                dispositions=[item.model_dump() for item in final.range_dispositions],
                uncertainties=final.uncertainties,
                message_count=len(messages),
                window_count=len(windows),
                usage=collector.summary(),
            )
            yield sequencer.event(
                "ledger_synthesis_completed",
                data={
                    "evidence_range_count": len(ledger.records),
                    "input_tokens": usage.input_tokens,
                    "output_tokens": usage.output_tokens,
                    "usage_source": usage.source,
                    "estimated_cost": usage.cost,
                },
            )
            logged("request_completed")
            yield sequencer.event("completed", result=result)
        except asyncio.CancelledError:
            for task in active_tasks:
                task.cancel()
            await asyncio.gather(*active_tasks, return_exceptions=True)
            logged("client_cancelled", severity="WARNING")
            raise
        except Exception as exc:
            stage = (
                "ledger"
                if isinstance(exc, LedgerError)
                else "window"
                if isinstance(exc, UnsplittableMessage)
                else "provider"
            )
            info = map_error(exc, stage=stage)
            logged("request_failed", stage=info.stage, error_code=info.code, http_status=info.status)
            yield sequencer.event(
                "failed",
                error={
                    "request_id": request.request_id,
                    "code": info.code,
                    "message": info.message,
                    "stage": info.stage,
                    "retryable": info.retryable,
                    "details": info.details or {},
                },
            )

    return StreamingResponse(stream(), media_type="application/x-ndjson")
