import shutil
import socket
import threading
import time
from dataclasses import replace
from datetime import date
from pathlib import Path

import pytest
import uvicorn

from message_evidence_workstation.client_api.contracts import StreamEvent
from message_evidence_workstation.client_api.gateway import RemoteGateway
from message_evidence_workstation.db.corpus_repository import WorkingCorpusRepository
from message_evidence_workstation.db.workspace_store import WorkspaceStore
from message_evidence_workstation.domain.search_scope import NarrowedSearchScope
from message_evidence_workstation.logging_ui.diagnostic_logger import DiagnosticLogger
from message_evidence_workstation.services.client_workflows import (
    ClientWorkflowService,
    ConversationalWorkflow,
    EmbeddingBuildCoordinator,
    EmbeddingSearchWorkflow,
    KeywordSearchWorkflow,
)
from message_evidence_workstation.services.corpus_builder import build_working_corpus
from message_evidence_workstation.services.import_dataset import import_normalized_dataset
from server.app import create_app
from server.config import EmbeddingConfig, GlobalConfig
from tests.sfv1_support import configured_service, fake_embedding_service, fake_provider, server_config


class FakeGateway:
    def __init__(self, transaction_open):
        self.transaction_open = transaction_open
        self.embedding_calls = []
        self.fail_first_embedding = True

    def _outside_transaction(self):
        assert not self.transaction_open(), "network call occurred while an EVW read transaction was open"

    def keyword_expansion(self, query):
        self._outside_transaction()
        return ["school"]

    def conversational_analysis(self, *, question, scope_id, messages):
        self._outside_transaction()
        first = messages[0]
        result = {
            "answer": "The first scoped message discusses school.",
            "answer_summary": "School evidence found.",
            "strategy": "whole_corpus",
            "evidence_ledger": [{"range_id": "r000001", "thread_id": first["thread_id"], "start_message_id": first["message_id"], "end_message_id": first["message_id"], "summary": "School discussion.", "relevance": "Directly relevant.", "disposition": "used", "rationale": "Supports the answer."}],
            "uncertainties": [],
            "coverage": {"message_count": len(messages), "window_count": 1, "evidence_range_count": 1},
            "usage": {"input_tokens": 10, "output_tokens": 5, "source": "provider_reported", "estimated_cost": None, "cost_complete": False, "currency": "USD"},
        }
        yield StreamEvent({"event": "accepted", "data": {"message_count": len(messages)}})
        yield StreamEvent({"event": "completed", "result": result})

    def embeddings(self, items):
        self._outside_transaction()
        ids = [item["message_id"] for item in items]
        self.embedding_calls.append(ids)
        accepted = {"embedding_profile_id": "emb-test-profile", "dimensions": 3, "normalization": "unit_l2", "model": "fake", "requested_revision": "v1"}
        yield StreamEvent({"event": "accepted", "data": accepted})
        midpoint = max(1, len(items) // 2)
        batches = [items[:midpoint], items[midpoint:]] if len(items) > 1 else [items]
        for batch_index, batch in enumerate(batches):
            if not batch:
                continue
            yield StreamEvent({"event": "embedding_batch_started", "data": {"batch_index": batch_index, "batch_count": len(batches)}})
            yield StreamEvent({"event": "vector_batch", "data": {"batch_index": batch_index, "items": [{"message_id": item["message_id"], "vector": [1.0, 0.0, 0.0]} for item in batch]}})
            if self.fail_first_embedding and len(items) > 1 and batch_index == 0:
                self.fail_first_embedding = False
                yield StreamEvent({"event": "failed", "error": {"code": "EMBEDDING_ERROR", "message": "synthetic partial failure"}})
                return
        yield StreamEvent({"event": "completed", "result": {"total_items": len(items), "embedding_profile_id": "emb-test-profile"}})


@pytest.fixture
def client_workspace(tmp_path):
    logger = DiagnosticLogger(log_bus=None)
    path = tmp_path / "client.evw"
    store = WorkspaceStore(path, logger).open(create=True, display_name="client-test")
    dataset_dir = Path(__file__).parent / "fixtures" / "sample_dataset"
    dataset_id = store.write(import_normalized_dataset, logger, dataset_dir)
    build = store.write(build_working_corpus, logger, dataset_id=dataset_id, name="Test working corpus", selection_mode="all")
    try:
        yield store, logger, dataset_id, build.scope, path
    finally:
        store.close()


def test_python_client_keeps_network_outside_transactions_and_persists_only_success(client_workspace):
    store, logger, dataset_id, working_scope, path = client_workspace
    state = {"reading": False}
    original_read = store.read

    def tracked_read(fn, *args, **kwargs):
        def wrapped(conn, *inner_args, **inner_kwargs):
            state["reading"] = True
            try:
                return fn(conn, *inner_args, **inner_kwargs)
            finally:
                state["reading"] = False
        return original_read(wrapped, *args, **kwargs)

    store.read = tracked_read
    gateway = FakeGateway(lambda: state["reading"])
    scope = NarrowedSearchScope(working_scope)

    fts = store.read(lambda conn: ClientWorkflowService(conn, logger, gateway).fts5_search(scope, "school"))
    assert fts["total_count"] > 0
    keyword = KeywordSearchWorkflow(store, logger, gateway).execute(scope, "school form")
    assert keyword["terms"] == ["school"] and keyword["total_count"] > 0

    conversation = ConversationalWorkflow(store, logger, gateway).execute(scope, "What mentions school?")
    assert conversation.persistence_warning is None
    stored = store.read(lambda conn: (conn.execute("SELECT COUNT(*) FROM conversation_turn").fetchone()[0], conn.execute("SELECT message_id,citation_type FROM conversation_citation").fetchall()))
    assert stored[0] == 1
    assert [(row["message_id"], row["citation_type"]) for row in stored[1]] == [("msg_001", "range_start")]

    with pytest.raises(Exception, match="partial failure"):
        EmbeddingBuildCoordinator(store, logger, gateway).build(working_scope)
    def vector_count(conn):
        return int(conn.execute("SELECT COUNT(*) FROM embedding_artifact").fetchone()[0])
    committed_after_failure = store.read(vector_count)
    assert committed_after_failure > 0
    build = EmbeddingBuildCoordinator(store, logger, gateway).build(working_scope)
    assert build.message_count == 100 and build.chunk_count == 0
    assert len(gateway.embedding_calls[1]) == 100 - committed_after_failure

    hits = EmbeddingSearchWorkflow(store, logger, gateway).execute(scope, "school", top_k=5)
    assert hits and all(hit["message_id"].startswith("msg_") for hit in hits)
    assert all(call for call in gateway.embedding_calls)

    assert store.checkpoint()[0] == 0


def test_real_http_server_and_v15_client_execute_both_conversation_strategies(client_workspace, tmp_path):
    store, logger, _dataset_id, working_scope, _path = client_workspace
    selected = server_config(
        global_config=GlobalConfig(
            window_target_input_tokens=1_600,
            maximum_concurrent_windows=2,
        ),
        embedding=EmbeddingConfig(
            model_name="fake",
            required_dimensions=3,
            internal_batch_size=17,
            progress_min_interval_ms=0,
        ),
    )
    operations = dict(selected.operations)
    operations["whole_corpus_answer"] = replace(
        operations["whole_corpus_answer"],
        target_input_tokens=1_200,
    )
    selected = replace(selected, operations=operations)
    config_service, _ = configured_service(tmp_path / "server-control", selected)
    app = create_app(
        config_service=config_service,
        provider=fake_provider(),
        embedding_service=fake_embedding_service(selected),
    )

    with socket.socket() as probe:
        probe.bind(("127.0.0.1", 0))
        port = int(probe.getsockname()[1])
    server = uvicorn.Server(
        uvicorn.Config(app, host="127.0.0.1", port=port, log_config=None, access_log=False)
    )
    thread = threading.Thread(target=server.run, name="v15-http-integration", daemon=True)
    thread.start()
    deadline = time.monotonic() + 10
    while not server.started and thread.is_alive() and time.monotonic() < deadline:
        time.sleep(0.02)
    assert server.started

    try:
        gateway = RemoteGateway(f"http://127.0.0.1:{port}", timeout_seconds=30)
        full_scope = NarrowedSearchScope(working_scope)
        first_day = NarrowedSearchScope(
            working_scope,
            start_date=date(2024, 1, 1),
            end_date=date(2024, 1, 1),
        )

        fts = store.read(
            lambda conn: ClientWorkflowService(conn, logger, gateway).fts5_search(
                full_scope, "school"
            )
        )
        assert fts["total_count"] > 0
        expanded = KeywordSearchWorkflow(store, logger, gateway).execute(
            full_scope, "school meeting"
        )
        assert expanded["total_count"] > 0

        whole_progress = []
        whole = ConversationalWorkflow(store, logger, gateway).execute(
            first_day,
            "What happened?",
            progress=whole_progress.append,
        )
        assert whole.result["strategy"] == "whole_corpus"
        assert whole.persistence_warning is None

        window_progress = []
        windowed = ConversationalWorkflow(store, logger, gateway).execute(
            full_scope,
            "What happened across the corpus?",
            progress=window_progress.append,
        )
        assert windowed.result["strategy"] == "windowed_ledger"
        assert windowed.result["coverage"]["window_count"] > 1
        assert any(item.phase == "window_completed" for item in window_progress)
        assert windowed.persistence_warning is None

        build = EmbeddingBuildCoordinator(store, logger, gateway).build(working_scope)
        assert build.message_count == 100
        hits = EmbeddingSearchWorkflow(store, logger, gateway).execute(
            full_scope, "school", top_k=5
        )
        assert hits
        persisted = store.read(
            lambda conn: conn.execute("SELECT COUNT(*) FROM conversation_turn").fetchone()[0]
        )
        assert persisted == 2
    finally:
        server.should_exit = True
        thread.join(timeout=15)
        assert not thread.is_alive()
