"""Explicit offline workspace tools."""
