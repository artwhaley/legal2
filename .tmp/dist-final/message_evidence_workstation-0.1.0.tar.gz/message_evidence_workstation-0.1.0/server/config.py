"""Explicit server-owned configuration models for Server-First V1."""

from __future__ import annotations

import os
from dataclasses import asdict, dataclass, field, replace
from pathlib import Path
from typing import Any


CONFIG_SCHEMA_VERSION = 1
CHAT_OPERATIONS = (
    "keyword_expansion",
    "retrieval_terms",
    "whole_corpus_answer",
    "window_evidence_extraction",
    "ledger_reduction",
    "ledger_synthesis",
)


def default_state_dir() -> Path:
    return Path(os.environ.get("EVW_SERVER_STATE_DIR", "~/.message_evidence_server")).expanduser().resolve()


@dataclass(frozen=True, slots=True)
class OperationConfig:
    provider_kind: str = "openai_compatible"
    base_url: str = ""
    model_id: str = ""
    system_prompt: str = ""
    structured_output_mode: str = "prompt_only"
    accounting_mode: str = "serialized_payload_tiktoken"
    encoding_name: str = "cl100k_base"
    tokenizer_name: str = ""
    tokenizer_revision: str = ""
    provider_wrapper_tokens: int = 0
    context_window_tokens: int = 0
    max_output_tokens: int = 0
    safety_margin_tokens: int = 0
    target_input_tokens: int | None = None
    connect_timeout_seconds: float = 10.0
    read_timeout_seconds: float = 600.0
    write_timeout_seconds: float = 60.0
    pool_timeout_seconds: float = 30.0
    operation_deadline_seconds: float = 900.0
    temperature: float = 0.0
    max_in_flight: int = 2
    max_queued: int = 24
    queue_wait_timeout_seconds: float = 30.0
    retryable_statuses: tuple[int, ...] = ()
    max_attempts: int = 1
    backoff_base_seconds: float = 1.0
    backoff_multiplier: float = 2.0
    backoff_cap_seconds: float = 30.0
    backoff_jitter_seconds: float = 0.0
    circuit_threshold: int = 0
    circuit_observation_seconds: float = 60.0
    circuit_cooldown_seconds: float = 30.0
    input_price_per_million: float | None = None
    output_price_per_million: float | None = None
    api_key: str = field(default="", repr=False, compare=False)

    def normalized(self) -> "OperationConfig":
        return replace(self, base_url=self.base_url.strip().rstrip("/"))

    def validate(self, operation: str, *, require_secret: bool = True) -> None:
        value = self.normalized()
        prefix = f"Operation {operation}"
        if value.provider_kind != "openai_compatible":
            raise ValueError(f"{prefix} provider_kind must be openai_compatible")
        if not require_secret and (not value.base_url.strip() or not value.model_id.strip() or value.context_window_tokens <= 0 or value.max_output_tokens <= 0):
            return
        if not value.base_url.startswith(("http://", "https://")):
            raise ValueError(f"{prefix} base_url must be an HTTP(S) URL")
        if value.base_url.endswith("/"):
            raise ValueError(f"{prefix} base_url must not have a trailing slash")
        if not value.model_id.strip():
            raise ValueError(f"{prefix} model_id is required")
        if not value.system_prompt.strip():
            raise ValueError(f"{prefix} system_prompt is required")
        if value.structured_output_mode not in {"json_schema", "json_object", "prompt_only"}:
            raise ValueError(f"{prefix} has unsupported structured_output_mode")
        if value.accounting_mode not in {"serialized_payload_tiktoken", "huggingface_chat_template"}:
            raise ValueError(f"{prefix} has unsupported accounting_mode")
        if value.accounting_mode == "serialized_payload_tiktoken" and not value.encoding_name.strip():
            raise ValueError(f"{prefix} encoding_name is required")
        if value.accounting_mode == "huggingface_chat_template" and not value.tokenizer_name.strip():
            raise ValueError(f"{prefix} tokenizer_name is required")
        for name, number in (("context_window_tokens", value.context_window_tokens), ("max_output_tokens", value.max_output_tokens)):
            if number <= 0:
                raise ValueError(f"{prefix} {name} must be positive")
        if value.safety_margin_tokens < 0 or value.max_output_tokens + value.safety_margin_tokens >= value.context_window_tokens:
            raise ValueError(f"{prefix} output and safety margin exceed context window")
        if value.target_input_tokens is not None and not 1 <= value.target_input_tokens <= value.context_window_tokens:
            raise ValueError(f"{prefix} target_input_tokens is outside context window")
        for name, number in (("connect_timeout_seconds", value.connect_timeout_seconds), ("read_timeout_seconds", value.read_timeout_seconds), ("write_timeout_seconds", value.write_timeout_seconds), ("pool_timeout_seconds", value.pool_timeout_seconds), ("operation_deadline_seconds", value.operation_deadline_seconds), ("queue_wait_timeout_seconds", value.queue_wait_timeout_seconds)):
            if number <= 0:
                raise ValueError(f"{prefix} {name} must be positive")
        if not 0 <= value.temperature <= 2:
            raise ValueError(f"{prefix} temperature must be between 0 and 2")
        if value.max_in_flight < 1 or value.max_queued < 0 or value.max_attempts < 1:
            raise ValueError(f"{prefix} concurrency/attempt settings are invalid")
        if any(status < 400 or status > 599 for status in value.retryable_statuses):
            raise ValueError(f"{prefix} retryable_statuses contains an invalid HTTP status")
        if value.backoff_base_seconds < 0 or value.backoff_multiplier < 1 or value.backoff_cap_seconds < 0 or value.backoff_jitter_seconds < 0:
            raise ValueError(f"{prefix} backoff settings are invalid")
        if value.circuit_threshold < 0 or value.circuit_observation_seconds <= 0 or value.circuit_cooldown_seconds <= 0:
            raise ValueError(f"{prefix} circuit settings are invalid")
        if require_secret and not value.api_key:
            raise ValueError(f"{prefix} API key is not configured")

    def to_dict(self, *, include_secret: bool = False) -> dict[str, Any]:
        data = asdict(self)
        data["retryable_statuses"] = list(self.retryable_statuses)
        if not include_secret:
            data.pop("api_key", None)
        return data

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "OperationConfig":
        allowed = {field.name for field in cls.__dataclass_fields__.values()}
        unknown = set(raw) - allowed
        if unknown:
            raise ValueError(f"Unknown operation fields: {', '.join(sorted(unknown))}")
        value = dict(raw)
        value["retryable_statuses"] = tuple(int(item) for item in value.get("retryable_statuses", ()))
        return cls(**value).normalized()


@dataclass(frozen=True, slots=True)
class GlobalConfig:
    maximum_product_request_bytes: int = 268_435_456
    maximum_conversational_corpus_tokens: int = 768_000
    maximum_embedding_items: int = 100_000
    maximum_embedding_request_bytes: int = 268_435_456
    product_max_in_flight: int = 12
    product_max_queued: int = 48
    global_queue_wait_timeout_seconds: float = 30.0
    provider_http_max_connections: int = 32
    provider_http_max_keepalive_connections: int = 16
    provider_http_keepalive_expiry_seconds: float = 30.0
    window_target_input_tokens: int = 128_000
    maximum_concurrent_windows: int = 2
    retrieval_assistance_enabled: bool = True
    ledger_reduction_max_depth: int = 4
    recent_event_ring_size: int = 2_000
    admin_auth_mode: str = "disabled"

    def validate(self) -> None:
        positive = ("maximum_product_request_bytes", "maximum_conversational_corpus_tokens", "maximum_embedding_items", "maximum_embedding_request_bytes", "product_max_in_flight", "provider_http_max_connections", "provider_http_max_keepalive_connections", "window_target_input_tokens", "maximum_concurrent_windows", "ledger_reduction_max_depth", "recent_event_ring_size")
        for name in positive:
            if getattr(self, name) <= 0:
                raise ValueError(f"global {name} must be positive")
        if self.product_max_queued < 0 or self.global_queue_wait_timeout_seconds <= 0 or self.provider_http_keepalive_expiry_seconds <= 0:
            raise ValueError("global queue/provider settings are invalid")
        if self.admin_auth_mode != "disabled":
            raise ValueError("only disabled admin_auth_mode is implemented in this phase")

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class EmbeddingConfig:
    model_name: str = ""
    model_revision: str = ""
    device: str = "cpu"
    normalization: str = "unit_l2"
    required_dimensions: int = 0
    internal_batch_size: int = 32
    worker_count: int = 1
    max_queued_workloads: int = 4
    maximum_items: int = 100_000
    maximum_request_bytes: int = 268_435_456
    executor_timeout_seconds: float = 3_600.0
    progress_min_interval_ms: int = 250

    def validate(self, *, require_model: bool = True) -> None:
        if require_model and not self.model_name.strip():
            raise ValueError("embedding model_name is required")
        if self.normalization not in {"unit_l2", "none"}:
            raise ValueError("embedding normalization must be unit_l2 or none")
        if self.required_dimensions < 0 or not 1 <= self.internal_batch_size or self.worker_count < 1 or self.max_queued_workloads < 0 or self.maximum_items <= 0 or self.maximum_request_bytes <= 0 or self.executor_timeout_seconds <= 0 or self.progress_min_interval_ms < 0:
            raise ValueError("embedding settings are invalid")

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class ServerConfig:
    config_version: int
    host: str
    port: int
    global_config: GlobalConfig
    operations: dict[str, OperationConfig]
    embedding: EmbeddingConfig

    def validate(self, *, require_complete: bool = True) -> None:
        if self.config_version <= 0:
            raise ValueError("config_version must be positive")
        if not self.host or not 1 <= self.port <= 65_535:
            raise ValueError("listener host/port is invalid")
        if self.global_config.admin_auth_mode == "disabled" and self.host not in {"127.0.0.1", "localhost", "::1"}:
            raise ValueError("non-loopback bind is forbidden while admin auth is disabled")
        self.global_config.validate()
        missing = [name for name in CHAT_OPERATIONS if name not in self.operations]
        extra = [name for name in self.operations if name not in CHAT_OPERATIONS]
        if missing or extra:
            raise ValueError(f"operation set mismatch; missing={missing}, extra={extra}")
        for name in CHAT_OPERATIONS:
            self.operations[name].validate(name, require_secret=require_complete)
        self.embedding.validate(require_model=require_complete)

    def to_dict(self, *, include_secrets: bool = False) -> dict[str, Any]:
        return {"config_version": self.config_version, "host": self.host, "port": self.port, "global_config": self.global_config.to_dict(), "operations": {name: value.to_dict(include_secret=include_secrets) for name, value in self.operations.items()}, "embedding": self.embedding.to_dict()}

    def without_secrets(self) -> "ServerConfig":
        return replace(
            self,
            operations={name: replace(value, api_key="") for name, value in self.operations.items()},
        )

    @classmethod
    def from_dict(cls, raw: dict[str, Any], *, config_version: int | None = None) -> "ServerConfig":
        unknown = set(raw) - {"config_version", "host", "port", "global_config", "operations", "embedding"}
        if unknown:
            raise ValueError(f"Unknown server configuration fields: {', '.join(sorted(unknown))}")
        operations_raw = raw.get("operations")
        if not isinstance(operations_raw, dict):
            raise ValueError("operations must be an object")
        global_raw = raw.get("global_config", {})
        if not isinstance(global_raw, dict):
            raise ValueError("global_config must be an object")
        embedding_raw = raw.get("embedding", {})
        if not isinstance(embedding_raw, dict):
            raise ValueError("embedding must be an object")
        return cls(config_version=int(config_version if config_version is not None else raw.get("config_version", 0)), host=str(raw.get("host", "127.0.0.1")), port=int(raw.get("port", 8710)), global_config=GlobalConfig(**global_raw), operations={name: OperationConfig.from_dict(value) for name, value in operations_raw.items()}, embedding=EmbeddingConfig(**embedding_raw))
