import json
import uuid
from dataclasses import replace

import httpx
from fastapi.testclient import TestClient

from server.app import create_app
from server.config import CHAT_OPERATIONS
from server.config_service import ConfigurationService
from server.provider import AsyncProvider
from tests.test_sfv1_control_store import make_config
from server.embeddings import EmbeddingService
from tests.sfv1_support import FakeEmbeddingModel


def app_with_fake(tmp_path, *, small=False):
    service = ConfigurationService(tmp_path)
    service.startup()
    draft = service.store.draft()[0]
    config = make_config()
    if small:
        config = replace(config, operations={name: replace(value, context_window_tokens=450, max_output_tokens=25, safety_margin_tokens=5) for name, value in config.operations.items()})
    service.store.save_draft(draft, config)
    for operation in CHAT_OPERATIONS:
        service.store.set_secret(draft, operation, "synthetic-secret-1234")
    service.activate(draft)

    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content)
        user = json.loads(payload["messages"][1]["content"])
        task = user["task"]
        if task == "whole_corpus_answer":
            messages = user["messages"]
            content = {"answer": "whole answer", "answer_summary": "whole summary", "evidence_ranges": [{"thread_id": messages[0]["thread_id"], "start_message_id": messages[0]["message_id"], "end_message_id": messages[-1]["message_id"], "summary": "support", "relevance": "relevant", "rationale": "direct support"}], "uncertainties": []}
        elif task == "retrieval_terms":
            content = {"terms": ["school"]}
        elif task == "window_evidence_extraction":
            content = {"window_id": user["window_id"], "no_relevant_evidence": True, "evidence_ranges": [], "uncertainties": ["none found"]}
        elif task == "ledger_synthesis":
            content = {"answer": "window answer", "answer_summary": "window summary", "range_dispositions": [], "uncertainties": ["none found"]}
        else:
            content = {"group_id": user.get("group_id", "g01-000001"), "summary": "reduced", "covered_range_ids": [item.get("range_id") for item in user.get("records_or_summaries", [])], "range_dispositions": [], "uncertainties": []}
        return httpx.Response(200, json={"choices": [{"message": {"content": json.dumps(content)}}], "usage": {"prompt_tokens": 10, "completion_tokens": 5}})

    provider = AsyncProvider(httpx.AsyncClient(transport=httpx.MockTransport(handler)))
    return create_app(config_service=service, provider=provider, embedding_service=EmbeddingService(config.embedding, model=FakeEmbeddingModel()))


def test_small_corpus_uses_one_whole_call_and_completes(tmp_path):
    app = app_with_fake(tmp_path)
    body = {"request_id": str(uuid.uuid4()), "question": "What happened?", "working_corpus": {"scope_id": "scope", "messages": [{"message_id": "m1", "thread_id": "t1", "timestamp": "2026-01-01T00:00:00Z", "sender": "a", "text": "one"}, {"message_id": "m2", "thread_id": "t1", "timestamp": "2026-01-01T00:01:00Z", "sender": "b", "text": "two"}]}}
    with TestClient(app) as client:
        response = client.post("/v1/conversational-analysis", json=body)
        assert response.status_code == 200
        events = [json.loads(line) for line in response.text.splitlines()]
        assert [event["event"] for event in events] == ["accepted", "accounting_completed", "whole_started", "whole_completed", "completed"]
        assert events[-1]["result"]["strategy"] == "whole_corpus"


def test_oversized_corpus_uses_all_windows_and_empty_synthesis(tmp_path):
    app = app_with_fake(tmp_path, small=True)
    messages = [{"message_id": f"m{i}", "thread_id": "t1", "timestamp": f"2026-01-01T00:{i:02d}:00Z", "sender": "a", "text": "x" * 95} for i in range(8)]
    body = {"request_id": str(uuid.uuid4()), "question": "What happened?", "working_corpus": {"scope_id": "scope", "messages": messages}}
    with TestClient(app) as client:
        response = client.post("/v1/conversational-analysis", json=body)
        assert response.status_code == 200
        events = [json.loads(line) for line in response.text.splitlines()]
        assert events[-1]["event"] == "completed"
        assert events[-1]["result"]["strategy"] == "windowed_ledger"
        assert events[-1]["result"]["coverage"]["message_count"] == 8
        assert sum(event["event"] == "window_started" for event in events) > 1
        assert sum(event["event"] == "window_completed" for event in events) == sum(event["event"] == "window_started" for event in events)
