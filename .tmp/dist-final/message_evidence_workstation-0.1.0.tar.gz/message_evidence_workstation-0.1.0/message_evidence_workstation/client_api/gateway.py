"""Temporary Python harness gateway for exactly three v1 product endpoints."""

from __future__ import annotations

import json
import urllib.error
import urllib.request
import uuid
from typing import Any, Iterator

from message_evidence_workstation.client_api.contracts import StreamEvent, validate_stream_value


class RemoteGatewayError(RuntimeError):
    def __init__(self, message: str, *, status_code: int | None = None, error_code: str | None = None, interrupted: bool = False):
        self.status_code = status_code
        self.error_code = error_code
        self.interrupted = interrupted
        super().__init__(message)


class RemoteGateway:
    def __init__(self, server_url: str, *, timeout_seconds: float = 120.0):
        self.server_url = server_url.rstrip("/")
        if not self.server_url.startswith(("http://", "https://")):
            raise ValueError("server URL must begin with http:// or https://")
        if timeout_seconds <= 0:
            raise ValueError("gateway timeout must be positive")
        self.timeout_seconds = timeout_seconds

    @staticmethod
    def _request_id() -> str:
        return str(uuid.uuid4())

    @staticmethod
    def _parse_http_error(exc: urllib.error.HTTPError) -> RemoteGatewayError:
        body = exc.read().decode("utf-8", errors="replace")
        try:
            error = json.loads(body)
        except json.JSONDecodeError:
            return RemoteGatewayError(f"Server HTTP {exc.code}: malformed error response", status_code=exc.code)
        required = {"request_id", "code", "message", "stage", "retryable", "details"}
        if not isinstance(error, dict) or set(error) != required:
            return RemoteGatewayError(f"Server HTTP {exc.code}: invalid error contract", status_code=exc.code)
        return RemoteGatewayError(str(error["message"]), status_code=exc.code, error_code=str(error["code"]))

    def _request(self, path: str, payload: dict[str, Any]) -> dict[str, Any]:
        data = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        request = urllib.request.Request(self.server_url + path, data=data, headers={"Content-Type": "application/json", "Accept": "application/json"}, method="POST")
        try:
            with urllib.request.urlopen(request, timeout=self.timeout_seconds) as response:
                body = response.read().decode("utf-8")
        except urllib.error.HTTPError as exc:
            raise self._parse_http_error(exc) from exc
        except (urllib.error.URLError, TimeoutError) as exc:
            raise RemoteGatewayError("Server connection failed or timed out") from exc
        try:
            result = json.loads(body)
        except json.JSONDecodeError as exc:
            raise RemoteGatewayError("Server returned malformed JSON") from exc
        if not isinstance(result, dict):
            raise RemoteGatewayError("Server returned a non-object JSON response")
        return result

    def keyword_expansion(self, query: str) -> list[str]:
        request_id = self._request_id()
        result = self._request("/v1/keyword-expansion", {"request_id": request_id, "query": query})
        if set(result) != {"request_id", "config_version", "terms", "usage"} or result.get("request_id") != request_id or not isinstance(result.get("config_version"), int):
            raise RemoteGatewayError("Server returned malformed keyword response")
        terms = result.get("terms")
        if not isinstance(terms, list) or not terms or any(not isinstance(term, str) or not term or term != term.strip() for term in terms) or len(terms) != len(set(terms)):
            raise RemoteGatewayError("Server returned malformed keyword terms")
        return terms

    def _stream(self, path: str, payload: dict[str, Any]) -> Iterator[StreamEvent]:
        data = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        request = urllib.request.Request(self.server_url + path, data=data, headers={"Content-Type": "application/json", "Accept": "application/x-ndjson"}, method="POST")
        expected_request_id = str(payload["request_id"])
        expected_sequence = 1
        config_version: int | None = None
        terminal: StreamEvent | None = None
        try:
            with urllib.request.urlopen(request, timeout=self.timeout_seconds) as response:
                content_type = response.headers.get_content_type()
                if content_type != "application/x-ndjson":
                    raise RemoteGatewayError("Server stream has the wrong content type", interrupted=True)
                for raw_line in response:
                    line = raw_line.decode("utf-8").strip()
                    if not line:
                        continue
                    if terminal is not None:
                        raise RemoteGatewayError("Server emitted data after its terminal event", interrupted=True)
                    try:
                        value = json.loads(line)
                        validate_stream_value(value, endpoint=path)
                    except (json.JSONDecodeError, ValueError) as exc:
                        raise RemoteGatewayError("Server stream violated its exact event contract", interrupted=True) from exc
                    if value["request_id"] != expected_request_id or value["sequence"] != expected_sequence:
                        raise RemoteGatewayError("Server stream changed request identity or sequence", interrupted=True)
                    if config_version is None:
                        config_version = value["config_version"]
                    elif value["config_version"] != config_version:
                        raise RemoteGatewayError("Server stream changed configuration version", interrupted=True)
                    event = StreamEvent(value)
                    expected_sequence += 1
                    if event.terminal:
                        terminal = event
                    else:
                        yield event
        except urllib.error.HTTPError as exc:
            raise self._parse_http_error(exc) from exc
        except (urllib.error.URLError, TimeoutError) as exc:
            raise RemoteGatewayError("Server stream connection failed or timed out", interrupted=True) from exc
        if terminal is None:
            raise RemoteGatewayError("Server stream ended before a terminal event", interrupted=True)
        yield terminal

    def conversational_analysis(self, *, question: str, scope_id: str, messages: list[dict[str, Any]]) -> Iterator[StreamEvent]:
        return self._stream("/v1/conversational-analysis", {"request_id": self._request_id(), "question": question, "working_corpus": {"scope_id": scope_id, "messages": messages}})

    def embeddings(self, items: list[dict[str, str]]) -> Iterator[StreamEvent]:
        return self._stream("/v1/embeddings", {"request_id": self._request_id(), "items": items})
