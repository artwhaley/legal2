import json
import uuid
from dataclasses import replace

import httpx
from fastapi.testclient import TestClient

from server.app import create_app
from server.config import GlobalConfig
from server.provider import AsyncProvider
from tests.sfv1_support import (
    configured_service,
    fake_embedding_service,
    fake_provider,
    output_for_user,
    server_config,
)


def body(messages):
    return {
        "request_id": str(uuid.uuid4()),
        "question": "What happened at the school meeting?",
        "working_corpus": {"scope_id": "scope", "messages": messages},
    }


def messages(count=2, text_size=20):
    return [
        {
            "message_id": f"m{i:03d}",
            "thread_id": "thread-1",
            "timestamp": f"2026-01-01T00:{i:02d}:00Z",
            "sender": "A" if i % 2 == 0 else "B",
            "text": f"message {i} " + "x" * text_size,
        }
        for i in range(count)
    ]


def window_config(*, synthesis_target=10_000, reduction_target=10_000, window_target=10_000):
    selected = server_config(
        context_window_tokens=20_000,
        max_output_tokens=1_000,
        global_config=GlobalConfig(window_target_input_tokens=window_target, maximum_concurrent_windows=2),
    )
    operations = dict(selected.operations)
    operations["whole_corpus_answer"] = replace(operations["whole_corpus_answer"], target_input_tokens=1)
    operations["window_evidence_extraction"] = replace(operations["window_evidence_extraction"], target_input_tokens=window_target)
    operations["ledger_synthesis"] = replace(operations["ledger_synthesis"], target_input_tokens=synthesis_target)
    operations["ledger_reduction"] = replace(operations["ledger_reduction"], target_input_tokens=reduction_target)
    return replace(selected, operations=operations)


def test_window_path_plans_after_retrieval_and_sends_exact_evidence_excerpts(tmp_path):
    calls = []
    config = window_config()
    service, _ = configured_service(tmp_path, config)
    app = create_app(config_service=service, provider=fake_provider(calls=calls), embedding_service=fake_embedding_service(config))
    submitted = messages()
    with TestClient(app) as client:
        response = client.post("/v1/conversational-analysis", json=body(submitted))
        events = [json.loads(line) for line in response.text.splitlines()]
    assert events[-1]["event"] == "completed"
    tasks = [call["user"]["task"] for call in calls]
    assert tasks.index("retrieval_terms") < tasks.index("window_evidence_extraction")
    window_call = next(call["user"] for call in calls if call["user"]["task"] == "window_evidence_extraction")
    assert window_call["retrieval_terms"] == ["school", "meeting"]
    synthesis = next(call["user"] for call in calls if call["user"]["task"] == "ledger_synthesis")
    exact = synthesis["records_or_highest_level_summaries"][0]["messages"]
    assert exact == submitted
    assert events[-1]["result"]["evidence_ledger"][0]["start_message_id"] == "m000"


def test_hierarchical_reduction_preserves_every_original_range_id(tmp_path):
    calls = []
    config = window_config(synthesis_target=1_250, reduction_target=2_500, window_target=1_000)
    service, _ = configured_service(tmp_path, config)
    app = create_app(config_service=service, provider=fake_provider(calls=calls), embedding_service=fake_embedding_service(config))
    with TestClient(app) as client:
        response = client.post("/v1/conversational-analysis", json=body(messages(8, 500)))
        events = [json.loads(line) for line in response.text.splitlines()]
    assert events[-1]["event"] == "completed", events[-1]
    reduction_calls = [call["user"] for call in calls if call["user"]["task"] == "ledger_reduction"]
    assert reduction_calls
    expected = [item["range_id"] for item in next(call["user"] for call in calls if call["user"]["task"] == "ledger_synthesis")["ledger_metadata"]]
    covered = []
    highest = next(call["user"] for call in reversed(calls) if call["user"]["task"] == "ledger_synthesis")["records_or_highest_level_summaries"]
    for item in highest:
        covered.extend(item["covered_range_ids"])
    assert covered == expected


def test_malformed_model_shape_fails_noisily_and_is_accounted_as_failure(tmp_path):
    def remove_required_field(user, output):
        if user["task"] == "whole_corpus_answer":
            del output["answer_summary"]
        return output

    config = server_config()
    service, _ = configured_service(tmp_path, config)
    app = create_app(config_service=service, provider=fake_provider(mutate=remove_required_field), embedding_service=fake_embedding_service(config))
    with TestClient(app) as client:
        response = client.post("/v1/conversational-analysis", json=body(messages()))
        events = [json.loads(line) for line in response.text.splitlines()]
        rows = service.store.conn.execute("SELECT outcome,error_code FROM usage_event WHERE internal_operation='whole_corpus_answer'").fetchall()
    assert events[-1]["event"] == "failed"
    assert events[-1]["error"]["code"] == "MODEL_OUTPUT_INVALID"
    assert [(row["outcome"], row["error_code"]) for row in rows] == [("failure", "MODEL_OUTPUT_INVALID")]


def test_configured_retry_is_visible_in_stream_and_every_attempt_is_accounted(tmp_path):
    attempts = 0

    async def handler(request):
        nonlocal attempts
        payload = json.loads(request.content)
        user = json.loads(payload["messages"][1]["content"])
        if user["task"] == "whole_corpus_answer":
            attempts += 1
            if attempts == 1:
                return httpx.Response(503, text="private provider body")
        return httpx.Response(
            200,
            json={
                "choices": [{"message": {"content": json.dumps(output_for_user(user))}}],
                "usage": {"prompt_tokens": 101, "completion_tokens": 23},
            },
        )

    config = server_config(
        operation_changes={
            "max_attempts": 2,
            "backoff_base_seconds": 0,
            "backoff_jitter_seconds": 0,
        }
    )
    service, _ = configured_service(tmp_path, config)
    provider = AsyncProvider(httpx.AsyncClient(transport=httpx.MockTransport(handler)))
    app = create_app(
        config_service=service,
        provider=provider,
        embedding_service=fake_embedding_service(config),
    )
    with TestClient(app) as client:
        response = client.post("/v1/conversational-analysis", json=body(messages()))
        events = [json.loads(line) for line in response.text.splitlines()]
        rows = service.store.conn.execute(
            "SELECT attempt,outcome,error_code FROM usage_event "
            "WHERE internal_operation='whole_corpus_answer' ORDER BY created_at"
        ).fetchall()

    names = [event["event"] for event in events]
    assert attempts == 2
    assert names.index("retry_wait") < names.index("whole_completed")
    retry = next(event for event in events if event["event"] == "retry_wait")
    assert retry["data"] == {
        "operation": "whole_corpus_answer",
        "failed_attempt": 1,
        "next_attempt": 2,
        "delay_ms": 0,
        "error_code": "PROVIDER_UNAVAILABLE",
    }
    assert [(row["attempt"], row["outcome"], row["error_code"]) for row in rows] == [
        (1, "failure", "PROVIDER_UNAVAILABLE"),
        (2, "success", None),
    ]
