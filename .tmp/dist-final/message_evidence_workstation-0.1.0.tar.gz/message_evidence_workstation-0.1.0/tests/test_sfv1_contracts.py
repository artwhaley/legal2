import uuid

import pytest
from pydantic import ValidationError

from server.contracts import (
    ConversationalAnalysisRequest,
    KeywordExpansionOutput,
    WindowEvidenceOutput,
    parse_ndjson_event,
)


def request_id() -> str:
    return str(uuid.uuid4())


def test_requests_reject_unknown_fields_and_wrong_types():
    with pytest.raises(ValidationError):
        ConversationalAnalysisRequest.model_validate({"request_id": request_id(), "question": "q", "working_corpus": {"scope_id": "s", "messages": []}, "extra": 1})
    with pytest.raises(ValidationError):
        KeywordExpansionOutput.model_validate({"terms": [1]})


def test_window_evidence_requires_exact_empty_or_nonempty_shape():
    with pytest.raises(ValidationError):
        WindowEvidenceOutput.model_validate({"window_id": "w1", "no_relevant_evidence": True, "evidence_ranges": [{"thread_id": "t", "start_message_id": "m1", "end_message_id": "m1", "summary": "s", "relevance": "r"}], "uncertainties": []})


def test_stream_event_rejects_unknown_and_wrong_terminal_shape():
    base = {"request_id": request_id(), "sequence": 1, "timestamp": "2026-01-01T00:00:00Z", "config_version": 1}
    with pytest.raises(ValidationError):
        parse_ndjson_event({**base, "event": "failed", "error": {"request_id": base["request_id"], "code": "X", "message": "x", "stage": "provider", "retryable": False, "details": {}, "extra": 1}}, endpoint="/v1/embeddings")
    with pytest.raises(ValidationError):
        parse_ndjson_event({**base, "event": "completed", "result": {"total_items": 1, "embedding_profile_id": "p"}}, endpoint="/v1/conversational-analysis")


def test_exact_event_data_rejects_missing_required_fields():
    base = {"request_id": request_id(), "sequence": 1, "timestamp": "2026-01-01T00:00:00Z", "config_version": 1}
    with pytest.raises(ValidationError):
        parse_ndjson_event({**base, "event": "window_plan_created", "data": {"window_count": 1, "message_count": 1}}, endpoint="/v1/conversational-analysis")
    with pytest.raises(ValidationError):
        parse_ndjson_event({**base, "event": "embedding_progress", "data": {"completed_items": 1, "total_items": 1, "server_items_per_second": 0.0, "extra": 1}}, endpoint="/v1/embeddings")
