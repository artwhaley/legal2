import asyncio
import json
import statistics
import time
import uuid
from collections import defaultdict
from dataclasses import replace

import httpx
import pytest

from server.app import create_app
from server.config import EmbeddingConfig, GlobalConfig
from server.embeddings import EmbeddingService
from server.provider import AsyncProvider
from tests.sfv1_support import FakeEmbeddingModel, configured_service, output_for_user, server_config


@pytest.mark.scale
def test_twelve_user_mixed_load_is_bounded_and_admin_stays_responsive(tmp_path):
    operations_active = defaultdict(int)
    operations_max = defaultdict(int)
    lock = asyncio.Lock()

    async def handler(request):
        payload = json.loads(request.content)
        user = json.loads(payload["messages"][1]["content"])
        operation = user["task"]
        async with lock:
            operations_active[operation] += 1
            operations_max[operation] = max(operations_max[operation], operations_active[operation])
        try:
            await asyncio.sleep(0.01)
            return httpx.Response(200, json={"choices": [{"message": {"content": json.dumps(output_for_user(user))}}], "usage": {"prompt_tokens": 50, "completion_tokens": 10}})
        finally:
            async with lock:
                operations_active[operation] -= 1

    global_config = GlobalConfig(product_max_in_flight=4, product_max_queued=20, global_queue_wait_timeout_seconds=5, window_target_input_tokens=2_000, maximum_concurrent_windows=2)
    embedding_config = EmbeddingConfig(model_name="fake", required_dimensions=3, internal_batch_size=25, worker_count=1, max_queued_workloads=8)
    config = server_config(context_window_tokens=6_000, max_output_tokens=500, global_config=global_config, embedding=embedding_config, operation_changes={"max_in_flight": 2, "max_queued": 20, "queue_wait_timeout_seconds": 5})
    service, _ = configured_service(tmp_path, config)
    provider = AsyncProvider(httpx.AsyncClient(transport=httpx.MockTransport(handler)))
    app = create_app(config_service=service, provider=provider, embedding_service=EmbeddingService(config.embedding, model=FakeEmbeddingModel(delay=0.005)))

    small_messages = [{"message_id": "m1", "thread_id": "t1", "timestamp": "2026-01-01T00:00:00Z", "sender": "A", "text": "school meeting"}]
    large_messages = [{"message_id": f"m{i}", "thread_id": "t1", "timestamp": f"2026-01-01T00:{i:02d}:00Z", "sender": "A", "text": "school meeting " + "x" * 900} for i in range(10)]

    async def run():
        latencies = []
        async with app.router.lifespan_context(app):
            transport = httpx.ASGITransport(app=app)
            async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
                async def timed(coro):
                    started = time.perf_counter()
                    response = await coro
                    latencies.append((time.perf_counter() - started) * 1000)
                    return response

                work = []
                for i in range(3):
                    work.append(timed(client.post("/v1/keyword-expansion", json={"request_id": str(uuid.uuid4()), "query": f"school {i}"})))
                for i in range(2):
                    work.append(timed(client.post("/v1/conversational-analysis", json={"request_id": str(uuid.uuid4()), "question": "What happened?", "working_corpus": {"scope_id": f"small-{i}", "messages": small_messages}})))
                for i in range(3):
                    work.append(timed(client.post("/v1/conversational-analysis", json={"request_id": str(uuid.uuid4()), "question": "What happened?", "working_corpus": {"scope_id": f"large-{i}", "messages": large_messages}})))
                for i in range(2):
                    items = [{"message_id": f"u{i}-m{j}", "text": f"message {j}"} for j in range(100)]
                    work.append(timed(client.post("/v1/embeddings", json={"request_id": str(uuid.uuid4()), "items": items})))
                for _ in range(2):
                    work.append(timed(client.get("/admin/")))
                responses = await asyncio.gather(*work)
                admin_started = time.perf_counter()
                admin_response = await client.get("/admin/")
                admin_latency = (time.perf_counter() - admin_started) * 1000
                assert admin_response.status_code == 200
        return responses, latencies, admin_latency

    responses, latencies, admin_latency = asyncio.run(run())
    assert len(responses) == 12
    assert all(response.status_code == 200 for response in responses)
    for response in responses:
        if response.headers.get("content-type", "").startswith("application/x-ndjson"):
            events = [json.loads(line) for line in response.text.splitlines()]
            assert events[-1]["event"] == "completed", events[-1]
    assert all(maximum <= 2 for maximum in operations_max.values())
    assert admin_latency < 1_000
    ordered = sorted(latencies)
    p50 = statistics.median(ordered)
    p95 = ordered[min(len(ordered) - 1, int(len(ordered) * 0.95))]
    assert p50 < 5_000 and p95 < 10_000 and max(ordered) < 10_000
