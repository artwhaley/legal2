"""Lean Python client UI."""
